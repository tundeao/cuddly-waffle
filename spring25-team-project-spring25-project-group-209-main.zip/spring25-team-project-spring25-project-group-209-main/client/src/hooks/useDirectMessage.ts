import { ObjectId } from 'mongodb';
import { useEffect, useState } from 'react';
import {
  ChatUpdatePayload,
  DatabaseMessage,
  MessageInfoAllOptional,
  PopulatedDatabaseChat,
  PopulatedDatabaseMessage,
  ReactionOptions,
  SafeDatabaseUser,
} from '../types/types';
import useUserContext from './useUserContext';

import {
  createChat,
  createChatWithMessage,
  getChatById,
  getChatsByUser,
  sendMessage,
  removeParticipantInChat,
  addParticipantInChat,
  updateMessagesInChat,
  updateMessage,
} from '../services/chatService';

/**
 * useDirectMessage is a custom hook that provides state and functions for direct messaging between users.
 * It includes a selected user, messages, and a new message state.
 */

const useDirectMessage = () => {
  const { user, socket } = useUserContext();
  const [showCreatePanel, setShowCreatePanel] = useState<boolean>(false);
  const [showRemovePanel, setShowRemovePanel] = useState<boolean>(false);
  const [showAddPanel, setShowAddPanel] = useState<boolean>(false);
  const [userToRemove, setUserToRemove] = useState<string>('');
  const [userToAdd, setUserToAdd] = useState<SafeDatabaseUser | undefined>(undefined);
  const [chatToCreate, setChatToCreate] = useState<string[]>([]);
  const [selectedMessage, setSelectedMessage] = useState<PopulatedDatabaseMessage | null>(null);
  const [selectedChat, setSelectedChat] = useState<PopulatedDatabaseChat | null>(null);
  const [chats, setChats] = useState<PopulatedDatabaseChat[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleJoinChat = (chatID: ObjectId) => {
    socket.emit('joinChat', String(chatID));
  };

  const handleSendMessage = async (question?: ObjectId, answer?: ObjectId) => {
    if (newMessage.trim() && selectedChat?._id) {
      const message: Omit<DatabaseMessage, 'type' | '_id'> = {
        msg: newMessage,
        msgFrom: user.username,
        msgDateTime: new Date(),
        question,
        answer,
      };

      const chat = await sendMessage(message, selectedChat._id);

      setSelectedChat(chat);
      setError(null);
      setNewMessage('');
    } else {
      setError('Message cannot be empty');
    }
  };

  const handleChatSelect = async (chatID: ObjectId | undefined) => {
    if (!chatID) {
      setError('Invalid chat ID');
      return;
    }
    const chat = await getChatById(chatID);
    setSelectedChat(chat);
    handleJoinChat(chatID);
    const messagesToUpdate: MessageInfoAllOptional[] = [...chat.messages.filter(msg => !msg.read)];
    const updatedMessages = messagesToUpdate.map(msg => {
      const tempSeenBy: string[] | undefined =
        msg.seenBy && msg.msgFrom
          ? [...new Set([...msg.seenBy, user.username, msg.msgFrom])]
          : [user.username];
      const haveAllParticipants =
        tempSeenBy && chat.participants
          ? tempSeenBy.length === chat.participants.length &&
            tempSeenBy.every(value => chat.participants.includes(value)) &&
            chat.participants.every(value => tempSeenBy.includes(value))
          : false;
      if (msg.seenBy && haveAllParticipants) {
        return {
          ...msg,
          read: true,
          seenByAll: new Date(),
          seenBy: tempSeenBy,
        };
      }
      if (msg.seenBy && !msg.seenBy?.includes(user.username) && msg.msgFrom !== user.username) {
        return {
          ...msg,
          seenBy: [...msg.seenBy, user.username],
        };
      }
      if (user.username !== msg.msgFrom) {
        return {
          ...msg,
          seenBy: [user.username],
        };
      }
      return {
        ...msg,
      };
    });
    if (messagesToUpdate.length > 0) {
      updateMessagesInChat(chat._id, updatedMessages);
    }
  };

  const handleUserSelect = (selectedUser: SafeDatabaseUser) => {
    if (!chatToCreate.includes(selectedUser.username)) {
      setChatToCreate([selectedUser.username, ...chatToCreate]);
    }
  };

  const handleCreateChat = async () => {
    if (!chatToCreate) {
      setError('Please select a user to chat with');
      return;
    }

    const chat = await createChat([user.username, ...chatToCreate]);
    setSelectedChat(chat);
    handleJoinChat(chat._id);
    setShowCreatePanel(false);
  };

  const handleMessageUpdate = async (
    messageID: ObjectId | undefined,
    chatID: ObjectId | undefined,
    reactions: ReactionOptions[],
  ) => {
    if (!messageID || !chatID) {
      setError('Invalid message ID or Chat ID');
      return;
    }

    const chat = await updateMessage(messageID, chatID, reactions);

    setSelectedChat(chat);
    handleJoinChat(chat._id);
  };

  const handleRemoveUsers = async (selectedUser: string) => {
    if (!selectedChat) {
      setError('Please select a user a chat to remove users from');
      return;
    }
    const chat = await removeParticipantInChat(selectedChat?._id, selectedUser);
    setSelectedChat(chat);
    setShowRemovePanel(false);
    handleJoinChat(chat._id);
    setUserToRemove('');
  };

  const handleAddUsers = async (selectedUser: SafeDatabaseUser) => {
    if (!selectedChat) {
      setError('Please select a user a chat to remove users from');
      return;
    }

    const chat = await addParticipantInChat(selectedChat?._id, selectedUser._id);
    setSelectedChat(chat);
    setShowAddPanel(false);
    handleJoinChat(chat._id);
    setUserToAdd(undefined);
  };

  const handleCreateChatWithMessage = async (question?: ObjectId, answer?: ObjectId) => {
    if (!chatToCreate) {
      setError('Please select a user to chat with');
      return;
    }
    if (newMessage.trim()) {
      const messageFormatted: Omit<DatabaseMessage, '_id'> = {
        msg: newMessage,
        msgFrom: user.username,
        msgDateTime: new Date(),
        type: 'direct',
        question,
        answer,
      };
      const chat = await createChatWithMessage(
        [user.username, ...chatToCreate],
        [messageFormatted],
      );
      setSelectedChat(chat);
      handleJoinChat(chat._id);
      setError(null);
      setNewMessage('');
    } else {
      setError('Message cannot be empty');
    }
  };

  useEffect(() => {
    const fetchChats = async () => {
      const userChats = await getChatsByUser(user.username);
      setChats(userChats);
    };

    const handleChatUpdate = (chatUpdate: ChatUpdatePayload) => {
      const { chat, type } = chatUpdate;
      // add a type for messageUpdate
      switch (type) {
        case 'created': {
          if (chat.participants.includes(user.username)) {
            setChats(prevChats => [chat, ...prevChats]);
          }
          return;
        }
        case 'newMessage': {
          setSelectedChat(chat);
          return;
        }
        case 'updateMessages': {
          setSelectedChat(chat);
          return;
        }
        case 'newParticipant': {
          if (chat.participants.includes(user.username)) {
            setChats(prevChats => {
              if (prevChats.some(c => chat._id === c._id)) {
                return prevChats.map(c => (c._id === chat._id ? chat : c));
              }
              return [chat, ...prevChats];
            });
          }
          return;
        }
        case 'removeParticipant': {
          if (chat.participants.includes(user.username)) {
            setChats(prevChats => {
              if (prevChats.some(c => chat._id === c._id)) {
                return prevChats.map(c => (c._id === chat._id ? chat : c));
              }
              return [chat, ...prevChats];
            });
          } else {
            setChats(prevChat => prevChat.filter(c => c._id !== chat._id));
          }

          return;
        }
        default: {
          setError('Invalid chat update type');
        }
      }
    };

    fetchChats();

    socket.on('chatUpdate', handleChatUpdate);

    return () => {
      socket.off('chatUpdate', handleChatUpdate);
      socket.emit('leaveChat', String(selectedChat?._id));
    };
  }, [user.username, socket, selectedChat?._id]);

  return {
    selectedChat,
    chatToCreate,
    chats,
    newMessage,
    setNewMessage,
    showCreatePanel,
    setShowCreatePanel,
    showRemovePanel,
    setShowRemovePanel,
    handleSendMessage,
    handleChatSelect,
    handleUserSelect,
    handleCreateChat,
    selectedMessage,
    setSelectedMessage,
    handleCreateChatWithMessage,
    handleRemoveUsers,
    userToRemove,
    setUserToRemove,
    handleAddUsers,
    showAddPanel,
    setShowAddPanel,
    handleMessageUpdate,
    setUserToAdd,
    userToAdd,
    error,
    setChatToCreate,
  };
};

export default useDirectMessage;
