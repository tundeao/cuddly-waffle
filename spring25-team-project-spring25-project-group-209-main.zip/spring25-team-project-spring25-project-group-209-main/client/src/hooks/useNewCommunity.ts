import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Interest } from '../types/types';
import { createCommunity } from '../services/communityService';

/**
 * Custom hook to handle new community submission and form validation
 *
 * @returns title - The current value of the title input.
 * @returns text - The current value of the text input.
 * @returns tagNames - The current value of the tags input.
 * @returns titleErr - Error message for the title field, if any.
 * @returns textErr - Error message for the text field, if any.
 * @returns tagErr - Error message for the tag field, if any.
 * @returns postCommunity - Function to validate the form and submit a new community.
 */
const useNewCommunity = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [tagNames, setTagNames] = useState<string>('');

  const [titleErr, setTitleErr] = useState<string>('');
  const [descriptionErr, setDescriptionErr] = useState<string>('');
  const [tagErr, setTagErr] = useState<string>('');

  /**
   * Function to validate the form before submitting the community.
   *
   * @returns boolean - True if the form is valid, false otherwise.
   */
  const validateForm = (): boolean => {
    let isValid = true;

    if (!title) {
      setTitleErr('Title cannot be empty');
      isValid = false;
    } else if (title.length > 100) {
      setTitleErr('Title cannot be more than 100 characters');
      isValid = false;
    } else {
      setTitleErr('');
    }

    if (!description) {
      setDescriptionErr('Description text cannot be empty');
      isValid = false;
    } else {
      setDescriptionErr('');
    }

    const tagnames = tagNames.split(' ').filter(tagName => tagName.trim() !== '');

    for (const tagName of tagnames) {
      if (tagName.length > 20) {
        setTagErr('New tag length cannot be more than 20');
        isValid = false;
        break;
      }
    }

    return isValid;
  };

  /**
   * Function to post a community to the server.
   *
   * @returns title - The current value of the title input.
   */
  const postCommunity = async () => {
    if (!validateForm()) return;

    const tags = tagNames.split(' ').filter(tagName => tagName.trim() !== '');

    const interest: Interest = {
      title,
      description,
      tags,
    };

    const res = await createCommunity(interest);

    if (res && res._id) {
      navigate('/communities');
    }
  };

  return {
    title,
    setTitle,
    description,
    setDescription,
    tagNames,
    setTagNames,
    titleErr,
    descriptionErr,
    tagErr,
    postCommunity,
  };
};

export default useNewCommunity;
