import { useEffect, useState, useCallback } from 'react';
import useUserContext from './useUserContext';
import { SafeDatabaseUser, UserUpdatePayload } from '../types/types';
import { getUsersByInterest } from '../services/userService';

const useCommunityCard = (interestTitle: string) => {
  const { socket } = useUserContext();
  const [communityUserList, setCommunityUserList] = useState<SafeDatabaseUser[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await getUsersByInterest(interestTitle);
        setCommunityUserList(res || []);
      } catch (error) {
        // eslint-disable-next-line no-console
        console.log(error);
      }
    };

    fetchData();
  }, [interestTitle]);

  const handleCommunityUserUpdate = useCallback(
    (userUpdate: UserUpdatePayload) => {
      setCommunityUserList(prevList => {
        const updatedUser = userUpdate.user;

        // removes username in userUpdate from all interests
        const updatedCommunityUserList = prevList.filter(
          user => user.username !== updatedUser.username,
        );

        // get all interest titles in userUpdate
        const updatedUserInterestTitles =
          updatedUser.interests?.map(interest =>
            typeof interest === 'object' && 'title' in interest ? interest.title : null,
          ) ?? [];

        // add back username for any interest titles in updatedUserInterestTitles
        if (updatedUserInterestTitles.includes(interestTitle)) {
          const currentUsernamesList = updatedCommunityUserList.map(user => user.username);
          if (!currentUsernamesList.includes(updatedUser.username)) {
            updatedCommunityUserList.push(updatedUser as SafeDatabaseUser);
          }
        }

        return [...updatedCommunityUserList];
      });
    },
    [interestTitle],
  );

  useEffect(() => {
    socket.on('userUpdate', handleCommunityUserUpdate);
    return () => {
      socket.off('userUpdate', handleCommunityUserUpdate);
    };
  }, [handleCommunityUserUpdate, socket]);

  return { communityUserList };
};

export default useCommunityCard;
