import { useEffect, useState } from 'react';
import useUserContext from './useUserContext';
import { DatabaseInterest } from '../types/types';
import { getCommunities } from '../services/communityService';

/**
 * Custom hook for managing the community list page state, filtering, and real-time updates.
 *
 * @returns communityList - The list of communites to display (filtered)
 * @returns setCommunityFilter - Function to set the filtering value of the community search.
 */
const useCommunityListPage = () => {
  const { socket } = useUserContext();
  const [communityList, setCommunityList] = useState<DatabaseInterest[]>([]);
  const [communityFilter, setCommunityFilter] = useState<string>('');

  useEffect(() => {
    /**
     * Function to fetch communites based and update the communities list
     */
    const fetchData = async () => {
      try {
        const res = await getCommunities();
        setCommunityList(res || []);
      } catch (error) {
        // eslint-disable-next-line no-console
        console.log(error);
      }
    };

    /**
     * Function to handle community updates from the socket.
     *
     * @param interest - the updated interest object.
     */
    const handleCommunityUpdate = (interest: DatabaseInterest) => {
      setCommunityList(prevCommunityList => [...prevCommunityList, interest]);
    };

    fetchData();

    socket.on('communityUpdate', handleCommunityUpdate);
  }, [socket]);
  const filteredCommunitylist = communityList.filter(community =>
    community.title.toLowerCase().startsWith(communityFilter.toLowerCase()),
  );
  return { filteredCommunitylist, setCommunityFilter };
};

export default useCommunityListPage;
