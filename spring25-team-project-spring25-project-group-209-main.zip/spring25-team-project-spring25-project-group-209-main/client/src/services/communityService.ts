import axios from 'axios';
import { Interest, DatabaseInterest } from '../types/types';
import api from './config';

const INTEREST_API_URL = `${process.env.REACT_APP_SERVER_URL}/interests`;

/**
 * Function to get communities
 *
 * @throws Error if there is an issue fetching communities.
 */
const getCommunities = async (): Promise<DatabaseInterest[]> => {
  const res = await api.get(`${INTEREST_API_URL}/getInterests`);
  if (res.status !== 200) {
    throw new Error('Error when fetching interests');
  }
  return res.data;
};

/**
 * Sends a POST request to create a new community.
 *
 * @param interest - The interest object to add.
 * @returns {Promise<Interest>} The newly created interest object.
 * @throws {Error} If an error occurs during the signup process.
 */
const createCommunity = async (interest: Interest): Promise<DatabaseInterest> => {
  try {
    const res = await api.post(`${INTEREST_API_URL}/addInterest`, interest);
    return res.data;
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      throw new Error(`Error while creating community: ${error.response.data}`);
    } else {
      throw new Error('Error while creating community');
    }
  }
};

export { getCommunities, createCommunity };
