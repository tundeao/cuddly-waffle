import { ObjectId } from 'mongodb';
import {
  DatabaseMessage,
  MessageInfoAllOptional,
  PopulatedDatabaseChat,
  ReactionOptions,
} from '../types/types';
import api from './config';

const CHAT_API_URL = `${process.env.REACT_APP_SERVER_URL}/chat`;

/**
 * Fetches all chats associated with a given user.
 *
 * @param username - The username of the user whose chats are to be fetched.
 * @returns The list of chats for the specified user.
 * @throws Throws an error if the fetch fails or if the status code is not 200.
 */
export const getChatsByUser = async (username: string): Promise<PopulatedDatabaseChat[]> => {
  const res = await api.get(`${CHAT_API_URL}/getChatsByUser/${username}`);

  if (res.status !== 200) {
    throw new Error('Error when fetching chats for user');
  }

  return res.data;
};

/**
 * updates the read or reaction fields within a pre-existing message
 *
 * @param chatID - The ID of the chat to fetch.
 *  @param messageId - id of the message want to update
 * @param read - optional update to read field
 * @param reactions - optional update to reaction fields
 * @returns The details of the chat with the updated fields
 * @throws Throws an error if the fetch fails or if the status code is not 200.
 */
export const updateMessagesInChat = async (
  chatID: ObjectId,
  messages: MessageInfoAllOptional[],
): Promise<PopulatedDatabaseChat> => {
  const res = await api.post(`${CHAT_API_URL}//${chatID}/updateMessages`, { messages });

  if (res.status !== 200) {
    throw new Error('Error when updating messaging in chat');
  }

  return res.data;
};

/**
 * Fetches a chat by its unique ID.
 *
 * @param chatID - The ID of the chat to fetch.
 * @returns The details of the chat with the specified ID.
 * @throws Throws an error if the fetch fails or if the status code is not 200.
 */
export const getChatById = async (chatID: ObjectId): Promise<PopulatedDatabaseChat> => {
  const res = await api.get(`${CHAT_API_URL}/${chatID}`);

  if (res.status !== 200) {
    throw new Error('Error when fetching chat by ID');
  }

  return res.data;
};

/**
 * removes a user from a chat.
 *
 * @param chatID - The ID of the chat to fetch.
 * @param username - username of user to remove
 * @returns The details of the chat with the specified ID.
 * @throws Throws an error if the fetch fails or if the status code is not 200.
 */
export const removeParticipantInChat = async (
  chatID: ObjectId,
  username: string,
): Promise<PopulatedDatabaseChat> => {
  const res = await api.post(`${CHAT_API_URL}/${chatID}/removeParticipants`, {
    username,
  });

  if (res.status !== 200) {
    throw new Error('Error when when removing a participant from chat');
  }

  return res.data;
};

/**
 * removes a user from a chat.
 *
 * @param chatID - The ID of the chat to fetch.
 * @param userId - the ID of user to remove
 * @returns The details of the chat with the specified ID.
 * @throws Throws an error if the fetch fails or if the status code is not 200.
 */
export const addParticipantInChat = async (
  chatID: ObjectId,
  userId: ObjectId,
): Promise<PopulatedDatabaseChat> => {
  const res = await api.post(`${CHAT_API_URL}/${chatID}/addParticipant`, {
    username: userId,
  });

  if (res.status !== 200) {
    throw new Error('Error when when adding a participant from chat');
  }

  return res.data;
};

/**
 * Sends a message to a specific chat.
 *
 * @param message - The message to be sent, excluding the 'type' property.
 * @param chatID - The ID of the chat to which the message will be added.
 * @returns The updated chat data after the message has been sent.
 * @throws Throws an error if the message could not be added to the chat.
 */
export const sendMessage = async (
  message: Omit<DatabaseMessage, 'type' | '_id'>,
  chatID: ObjectId,
): Promise<PopulatedDatabaseChat> => {
  const res = await api.post(`${CHAT_API_URL}/${chatID}/addMessage`, message);

  if (res.status !== 200) {
    throw new Error('Error when adding message to chat');
  }

  return res.data;
};

/**
 * Creates a new chat with the specified participants.
 *
 * @param participants - An array of user IDs representing the participants of the chat.
 * @returns The newly created chat data.
 * @throws Throws an error if the chat creation fails or if the status code is not 200.
 */
export const createChat = async (participants: string[]): Promise<PopulatedDatabaseChat> => {
  const res = await api.post(`${CHAT_API_URL}/createChat`, { participants, messages: [] });

  if (res.status !== 200) {
    throw new Error('Error when adding message to chat');
  }

  return res.data;
};

/**
 * Creates a new chat with the specified participants.
 *
 * @param participants - An array of user IDs representing the participants of the chat.
 * @returns The newly created chat data.
 * @throws Throws an error if the chat creation fails or if the status code is not 200.
 */
export const createChatWithMessage = async (
  participants: string[],
  messages: Omit<DatabaseMessage, '_id' | 'type'>[],
): Promise<PopulatedDatabaseChat> => {
  const res = await api.post(`${CHAT_API_URL}/createChat`, { participants, messages });

  if (res.status !== 200) {
    throw new Error('Error when adding message to chat');
  }

  return res.data;
};

/**
 * Sends a message to a specific chat.
 *
 * @param messageID - The message id of the message to be updated
 * @param reactions - list of ReactionOptions to add
 * @param chatID - The ID of the chat to which the message will be added.
 * @returns The updated chat data after the message has been sent.
 * @throws Throws an error if the message could not be added to the chat.
 */
export const updateMessage = async (
  messageID: ObjectId,
  chatID: ObjectId,
  reactions: ReactionOptions[],
): Promise<PopulatedDatabaseChat> => {
  const res = await api.post(`${CHAT_API_URL}/${chatID}/updateMessage`, {
    messageId: messageID,
    reactions,
  });

  if (res.status !== 200) {
    throw new Error('Error when when updating a specific message in chat');
  }

  return res.data;
};
