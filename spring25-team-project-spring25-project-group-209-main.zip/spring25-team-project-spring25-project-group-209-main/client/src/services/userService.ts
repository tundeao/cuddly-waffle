import axios from 'axios';
import { UserCredentials, SafeDatabaseUser } from '../types/types';
import api from './config';

const USER_API_URL = `${process.env.REACT_APP_SERVER_URL}/user`;

/**
 * Function to get users
 *
 * @throws Error if there is an issue fetching users.
 */
const getUsers = async (): Promise<SafeDatabaseUser[]> => {
  const res = await api.get(`${USER_API_URL}/getUsers`);
  if (res.status !== 200) {
    throw new Error('Error when fetching users');
  }
  return res.data;
};

/**
 * Function to get users
 *
 * @throws Error if there is an issue fetching users.
 */
const getUserByUsername = async (username: string): Promise<SafeDatabaseUser> => {
  const res = await api.get(`${USER_API_URL}/getUser/${username}`);
  if (res.status !== 200) {
    throw new Error('Error when fetching user');
  }
  return res.data;
};

/**
 * Sends a POST request to create a new user account.
 *
 * @param user - The user credentials (username and password) for signup.
 * @returns {Promise<User>} The newly created user object.
 * @throws {Error} If an error occurs during the signup process.
 */
const createUser = async (user: UserCredentials): Promise<SafeDatabaseUser> => {
  try {
    const res = await api.post(`${USER_API_URL}/signup`, user);
    return res.data;
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      throw new Error(`Error while signing up: ${error.response.data}`);
    } else {
      throw new Error('Error while signing up');
    }
  }
};

/**
 * Sends a POST request to authenticate a user.
 *
 * @param user - The user credentials (username and password) for login.
 * @returns {Promise<User>} The authenticated user object.
 * @throws {Error} If an error occurs during the login process.
 */
const loginUser = async (user: UserCredentials): Promise<SafeDatabaseUser> => {
  try {
    const res = await api.post(`${USER_API_URL}/login`, user);
    return res.data;
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      throw new Error(`Error while logging in: ${error.response.data}`);
    } else {
      throw new Error('Error while logging in');
    }
  }
};

/**
 * Deletes a user by their username.
 * @param username - The unique username of the user
 * @returns A promise that resolves to the deleted user data
 * @throws {Error} If the request to the server is unsuccessful
 */
const deleteUser = async (username: string): Promise<SafeDatabaseUser> => {
  const res = await api.delete(`${USER_API_URL}/deleteUser/${username}`);
  if (res.status !== 200) {
    throw new Error('Error when deleting user');
  }
  return res.data;
};

/**
 * Resets the password for a user.
 * @param username - The unique username of the user
 * @param newPassword - The new password to be set for the user
 * @returns A promise that resolves to the updated user data
 * @throws {Error} If the request to the server is unsuccessful
 */
const resetPassword = async (username: string, newPassword: string): Promise<SafeDatabaseUser> => {
  const res = await api.patch(`${USER_API_URL}/resetPassword`, {
    username,
    password: newPassword,
  });
  if (res.status !== 200) {
    throw new Error('Error when resetting password');
  }
  return res.data;
};

/**
 * Updates the user's biography.
 * @param username The unique username of the user
 * @param newBiography The new biography to set for this user
 * @returns A promise resolving to the updated user
 * @throws Error if the request fails
 */
const updateBiography = async (
  username: string,
  newBiography: string,
): Promise<SafeDatabaseUser> => {
  const res = await api.patch(`${USER_API_URL}/updateBiography`, {
    username,
    biography: newBiography,
  });
  if (res.status !== 200) {
    throw new Error('Error when updating biography');
  }
  return res.data;
};

/**
 * Function to get users by interest
 *
 * @throws Error if there is an issue fetching users.
 */
const getUsersByInterest = async (interestId: string): Promise<SafeDatabaseUser[]> => {
  const res = await api.get(`${USER_API_URL}/getUsersByInterest/${interestId}`);
  if (res.status !== 200) {
    throw new Error('Error when fetching users');
  }
  return res.data;
};

/**
 * Updates the user's biography.
 * @param username The unique username of the user
 * @param newBiography The new biography to set for this user
 * @returns A promise resolving to the updated user
 * @throws Error if the request fails
 */
const updateInterests = async (
  username: string,
  newInterestTitle: string,
  action: 'join' | 'leave',
): Promise<SafeDatabaseUser> => {
  const res = await api.patch(`${USER_API_URL}/updateInterests`, {
    username,
    interestTitle: newInterestTitle,
    action,
  });
  if (res.status !== 200) {
    throw new Error('Error when updating interests');
  }
  return res.data;
};

/**
 * Updates the user's badges (adds or removes a badge).
 * @param username The unique username of the user
 * @param badgeTitle The title of the badge
 * @param badgeDescription The description of the badge
 * @param badgeType The type of badge ('question' or 'answer')
 * @param action Whether to 'add' or 'remove' the badge
 * @param dateAwarded Optional date when the badge was awarded
 * @returns A promise resolving to the updated user
 * @throws Error if the request fails
 */
const updateBadge = async (
  username: string,
  badgeTitle: string,
  badgeDescription: string,
  badgeType: 'question' | 'answer',
  action: 'add' | 'remove',
  dateAwarded?: Date,
): Promise<SafeDatabaseUser> => {
  try {
    // Ensure dateAwarded is a valid Date object
    const awardDate = dateAwarded || new Date();
    const res = await api.patch(`${USER_API_URL}/updateBadge`, {
      username,
      badgeTitle,
      badgeDescription,
      badgeType,
      action,
      dateAwarded: awardDate,
    });

    if (res.status !== 200) {
      throw new Error(`Error when ${action === 'add' ? 'adding' : 'removing'} badge`);
    }

    return res.data;
  } catch (error) {
    throw new Error('Badge update failed');
  }
};

export {
  getUsers,
  getUserByUsername,
  loginUser,
  createUser,
  deleteUser,
  resetPassword,
  updateBiography,
  getUsersByInterest,
  updateBadge,
  updateInterests,
};
