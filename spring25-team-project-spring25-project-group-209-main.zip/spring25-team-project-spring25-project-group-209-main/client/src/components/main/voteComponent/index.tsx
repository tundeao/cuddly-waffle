import { useState } from 'react';
import { downvoteQuestion, upvoteQuestion } from '../../../services/questionService';
import { downvoteAnswer, upvoteAnswer } from '../../../services/answerService';
import { updateBadge, getUserByUsername } from '../../../services/userService';
import './index.css';
import useUserContext from '../../../hooks/useUserContext';
import {
  PopulatedDatabaseAnswer,
  PopulatedDatabasePost,
  PopulatedDatabaseQuestion,
} from '../../../types/types';
import useVoteStatus from '../../../hooks/useVoteStatus';

const BADGE_THRESHOLDS = [1, 2, 3];
const badgeNames = {
  1: 'Bronze Badge',
  2: 'Silver Badge',
  3: 'Gold Badge',
};

/**
 * Determines if a post is a question
 *
 * @param post - The post to check
 * @returns True if the post is a question, false otherwise
 */
function isQuestion(post: PopulatedDatabasePost): post is PopulatedDatabaseQuestion {
  return 'title' in post;
}

/**
 * Interface represents the props for the VoteComponent.
 *
 * post - The post object (question or answer) containing voting information.
 */
interface VoteComponentProps {
  post: PopulatedDatabasePost;
}

/**
 * A Vote component that allows users to upvote or downvote a post (question or answer).
 *
 * @param post - The post object containing voting information.
 */
const VoteComponent = ({ post }: VoteComponentProps) => {
  const { user } = useUserContext();
  const { count, voted } = useVoteStatus({ post });
  const [isBadgeAwarded, setIsBadgeAwarded] = useState(false);
  const [awardedBadge, setAwardedBadge] = useState('');

  /**
   * Calculates the new vote count after a vote operation
   *
   * @param currentCount - The current vote count
   * @param type - The type of vote ('upvote' or 'downvote')
   * @param currentVoted - The current vote status (1 for upvoted, -1 for downvoted, 0 for not voted)
   * @returns The new vote count
   */
  const calculateNewCount = (currentCount: number, type: string, currentVoted: number): number => {
    // If upvoting
    if (type === 'upvote') {
      if (currentVoted === 1) {
        // Cancel upvote: -1
        return currentCount - 1;
      }

      if (currentVoted === -1) {
        // Change from downvote to upvote: +2
        return currentCount + 2;
      }

      // New upvote: +1
      return currentCount + 1;
    }

    // If downvoting (type === 'downvote')
    if (currentVoted === -1) {
      // Cancel downvote: +1
      return currentCount + 1;
    }

    if (currentVoted === 1) {
      // Change from upvote to downvote: -2
      return currentCount - 2;
    }

    // New downvote: -1
    return currentCount - 1;
  };

  /**
   * Verifies a username exists in the database
   *
   * @param username - The username to verify
   * @returns boolean indicating if the user exists
   */
  const verifyUserExists = async (username: string): Promise<boolean> => {
    try {
      await getUserByUsername(username);
      return true;
    } catch (error) {
      return false;
    }
  };

  /**
   * Checks if a badge should be awarded based on the new vote count
   *
   * @param newCount - The updated vote count after voting
   * @param authorUsername - The username of the post's author
   * @param postType - The type of post ('question' or 'answer')
   */
  const checkAndAwardBadges = async (
    newCount: number,
    authorUsername: string,
    postType: 'question' | 'answer',
  ) => {
    try {
      // Check if the vote count hits any of our thresholds exactly
      const exactThreshold = BADGE_THRESHOLDS.find(threshold => threshold === newCount);

      if (exactThreshold && authorUsername) {
        // Verify the user exists before attempting to award a badge
        const userExists = await verifyUserExists(authorUsername);
        if (!userExists) {
          return;
        }

        const badgeName = badgeNames[exactThreshold as keyof typeof badgeNames];

        // Create a detailed description based on post type and content
        let badgeDescription = '';

        if (postType === 'question') {
          // For questions, include the question title
          const questionPost = post as PopulatedDatabaseQuestion;
          const truncatedTitle =
            questionPost.title.length > 50
              ? `${questionPost.title.substring(0, 50)}...`
              : questionPost.title;

          badgeDescription = `Received ${newCount} votes on the question: "${truncatedTitle}"`;
        } else {
          // For answers, include both the question title and a snippet of the answer
          const answerPost = post as PopulatedDatabaseAnswer;
          const truncatedAnswer =
            answerPost.text.length > 30
              ? `${answerPost.text.substring(0, 30)}...`
              : answerPost.text;

          badgeDescription = `Received ${newCount} votes on the answer: "${truncatedAnswer}"`;
        }

        // Call the service to update the badge in the database
        await updateBadge(authorUsername, badgeName, badgeDescription, postType, 'add');

        // Show notification in the UI
        setIsBadgeAwarded(true);
        setAwardedBadge(badgeName);

        // Hide the notification after 5 seconds
        setTimeout(() => {
          setIsBadgeAwarded(false);
          setAwardedBadge('');
        }, 5000);
      }
    } catch (error) {
      throw Error('Error awarding badge');
    }
  };

  /**
   * Function to handle upvoting or downvoting a post.
   *
   * @param type - The type of vote, either 'upvote' or 'downvote'.
   */
  const handleVote = async (type: string) => {
    try {
      if (!post._id) {
        return;
      }

      const { _id: postId } = post;
      const { username } = user;

      // Store previous vote count to compare after the vote
      const prevCount = count;

      let authorUsername = '';
      let postType: 'question' | 'answer';

      if (isQuestion(post)) {
        authorUsername = post.askedBy;
        postType = 'question';
        if (type === 'upvote') {
          await upvoteQuestion(postId, username);
        } else {
          await downvoteQuestion(postId, username);
        }
      } else {
        authorUsername = post.ansBy;
        postType = 'answer';
        const isUpvote = type === 'upvote';
        if (isUpvote) {
          await upvoteAnswer(postId, username);
        } else {
          await downvoteAnswer(postId, username);
        }
      }

      // Calculate new count based on vote result and previous state
      const newCount = calculateNewCount(prevCount, type, voted);

      await checkAndAwardBadges(newCount, authorUsername, postType);
    } catch (error) {
      throw Error('Vote error in handleVote');
    }
  };

  return (
    <div className='vote-container'>
      <button
        className={`vote-button ${voted === 1 ? 'vote-button-upvoted' : ''}`}
        onClick={() => handleVote('upvote')}>
        Upvote
      </button>
      <button
        className={`vote-button ${voted === -1 ? 'vote-button-downvoted' : ''}`}
        onClick={() => handleVote('downvote')}>
        Downvote
      </button>
      <span className='vote-count'>{count}</span>

      {/* Badge Award Notification */}
      {isBadgeAwarded && (
        <div className='badge-notification'>
          <span>
            🏆 {awardedBadge} awarded to {isQuestion(post) ? post.askedBy : post.ansBy}!
          </span>
        </div>
      )}
    </div>
  );
};

export default VoteComponent;
