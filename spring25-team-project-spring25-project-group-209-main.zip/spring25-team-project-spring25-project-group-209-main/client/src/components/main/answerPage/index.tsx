import React from 'react';
import { getMetaData } from '../../../tool';
import AnswerView from './answer';
import AnswerHeader from './header';
import { Comment } from '../../../types/types';
import './index.css';
import QuestionBody from './questionBody';
import VoteComponent from '../voteComponent';
import CommentSection from '../commentSection';
import useAnswerPage from '../../../hooks/useAnswerPage';

/**
 * AnswerPage component that displays the full content of a question along with its answers.
 * It also includes the functionality to vote, ask a new question, and post a new answer.
 */
const AnswerPage = () => {
  const { questionID, question, handleNewComment, handleNewAnswer } = useAnswerPage();

  if (!question) {
    return null;
  }

  return (
    <>
      <VoteComponent post={question} />
      <AnswerHeader
        ansCount={question.answers.length}
        title={question.title}
        questionId={question._id}
      />
      <QuestionBody
        views={question.views.length}
        text={question.text}
        askby={question.askedBy}
        meta={getMetaData(new Date(question.askDateTime))}
      />
      <CommentSection
        comments={question.comments}
        handleAddComment={(comment: Comment) => handleNewComment(comment, 'question', questionID)}
      />
      {question.answers.map(answer => (
        <div key={String(answer._id)} className='answer-container'>
          <VoteComponent post={answer} />
          <AnswerView
            text={answer.text}
            ansBy={answer.ansBy}
            meta={getMetaData(new Date(answer.ansDateTime))}
            comments={answer.comments}
            handleAddComment={(comment: Comment) =>
              handleNewComment(comment, 'answer', String(answer._id))
            }
          />
        </div>
      ))}
      <button
        className='bluebtn ansButton'
        onClick={() => {
          handleNewAnswer();
        }}>
        Answer Question
      </button>
    </>
  );
};

export default AnswerPage;
