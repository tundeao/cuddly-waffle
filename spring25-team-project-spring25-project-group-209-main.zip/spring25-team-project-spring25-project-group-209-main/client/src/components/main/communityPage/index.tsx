import React from 'react';
import './index.css';
import CommunityCardView from './communityCard';
import useCommunityListPage from '../../../hooks/useCommunityListPage';
import CreateCommunityButton from './createCommunityButton';
import CommunitiesListHeader from './communityHeader';

/**
 * CommunityListPage component renders a page displaying a list of communities
 */
const CommunityListPage = () => {
  const { filteredCommunitylist, setCommunityFilter } = useCommunityListPage();
  return (
    <div className='community-card-container'>
      <div className='community-header'>
        <div>
          <h1>All Communities</h1>
          <CommunitiesListHeader
            communityCount={filteredCommunitylist.length}
            setCommunityFilter={setCommunityFilter}
          />
        </div>
        <CreateCommunityButton />
      </div>
      <div id='community_list' className='community_list'>
        {filteredCommunitylist.map((community, index) => (
          <CommunityCardView key={index} interest={community} />
        ))}
      </div>
    </div>
  );
};
export default CommunityListPage;
