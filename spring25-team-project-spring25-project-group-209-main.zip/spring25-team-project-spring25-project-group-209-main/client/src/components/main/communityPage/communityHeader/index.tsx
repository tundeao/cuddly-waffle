import React from 'react';
import './index.css';
import useCommunitySearch from '../../../../hooks/useCommunitySearch';

/**
 * Interface representing the props for the CommunityListHeader component.
 *
 * communityCount - The number of communities to be displayed in the header.
 * setCommunityFilter - A function that sets the search bar filter value.
 */
interface CommunityHeaderProps {
  communityCount: number;
  setCommunityFilter: (search: string) => void;
}

/**
 * CommunitiesListHeader component displays the header section for a list of communities.
 * It includes the title and search bar to filter the communities.
 * Community search is incase-sensitive.
 *
 * @param communityCount - The number of communities displayed in the header.
 * @param setCommunityFilter - Function that sets the search bar filter value.
 */
const CommunitiesListHeader = ({ communityCount, setCommunityFilter }: CommunityHeaderProps) => {
  const { val, handleInputChange } = useCommunitySearch(setCommunityFilter);

  return (
    <div className='community_header_container'>
      <input
        id='community_search_bar'
        placeholder='Search For Communites ...'
        type='text'
        value={val}
        onChange={handleInputChange}
      />
      <div>{communityCount} communities</div>
    </div>
  );
};

export default CommunitiesListHeader;
