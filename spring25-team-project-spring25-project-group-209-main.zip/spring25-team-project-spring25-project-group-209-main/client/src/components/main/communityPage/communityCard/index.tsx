import React from 'react';
import './index.css';
import { Interest } from '../../../../types/types';
import useCommunityCard from '../../../../hooks/useCommunityCard';

/**
 * Interface representing the props for the Community component card.
 *
 * interest - The interest object containing details about the interest.
 */
interface CommunityProps {
  interest: Interest;
}

/**
 * Community component renders the details of interest including its title, description, optional tags and joined users.
 *
 * @param interest - The interest object containing interest details.
 */
const CommunityCardView = (props: CommunityProps) => {
  const { interest } = props;
  const { title, description, tags } = interest;
  const { communityUserList } = useCommunityCard(title);
  const joinedUsers = communityUserList.map(user => user.username);

  return (
    <div className='community_section'>
      <div className='community'>
        <div className='title_section'>
          <h2>{title}</h2>
          {tags && (
            <div className='tag_container'>
              {tags.map((tag, index) => (
                <div key={index} className='tag'>
                  {tag}
                </div>
              ))}
            </div>
          )}
        </div>
        <p>{description}</p>
      </div>
      {communityUserList.length > 0 && (
        <div className='user_container'>
          <h3>Joined users:</h3>
          <p>{joinedUsers.join(', ')}</p>
        </div>
      )}
    </div>
  );
};

export default CommunityCardView;
