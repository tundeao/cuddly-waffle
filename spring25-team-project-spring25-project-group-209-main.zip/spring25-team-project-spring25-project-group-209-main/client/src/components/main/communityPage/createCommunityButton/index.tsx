import React from 'react';
import { useNavigate } from 'react-router-dom';

/**
 * AddCommunityButton component that renders a button for navigating to the
 * "New Community" page. When clicked, it redirects the user to the page
 * where they can add a new community.
 */
const CreateCommunityButton = () => {
  const navigate = useNavigate();

  /**
   * Function to handle navigation to the "New Community" page.
   */
  const handleNewCommunity = () => {
    navigate('/new/community');
  };

  return (
    <button
      className='bluebtn'
      onClick={() => {
        handleNewCommunity();
      }}>
      Add a Community
    </button>
  );
};

export default CreateCommunityButton;
