import React from 'react';
import './index.css';
import { FaRegHeart } from 'react-icons/fa';
import { MdOutlineThumbUp, MdOutlineThumbDown } from 'react-icons/md';
import { LiaExclamationSolid } from 'react-icons/lia';
import { ObjectId } from 'mongodb';
import { Comment, PopulatedDatabaseMessage, ReactionOptions } from '../../../types/types';
import { getMetaData } from '../../../tool';
import AnswerView from '../answerPage/answer';

interface MessageCardProps {
  message: PopulatedDatabaseMessage;
  chatId: ObjectId | undefined;
  setSelectedMessage: (target: PopulatedDatabaseMessage) => void;
  selectedMessage: PopulatedDatabaseMessage | null;
  handleMessageUpdate: (
    messageID: ObjectId | undefined,
    chatID: ObjectId | undefined,
    reactions: ReactionOptions[],
  ) => Promise<void>;
}

/**
 * MessageCard component displays a single message with its sender and timestamp.
 *
 * @param message: The message object to display.
 */
const MessageCard = (props: MessageCardProps) => {
  const { message, setSelectedMessage, chatId, handleMessageUpdate } = props;
  return (
    <>
      <div className='message' onClick={() => setSelectedMessage(message)}>
        <div className='message-header'>
          <div className='message-sender'>{message.msgFrom}</div>
          <div className='message-time'>{getMetaData(new Date(message.msgDateTime))}</div>
        </div>
        <div className='message-body'>
          {message.question ? (
            <div style={{ borderTop: ' #000000 1px dashed', borderBottom: ' #000000 1px dashed' }}>
              <div className='question right_padding'>
                <div className='postStats'>
                  <div>{message.question.answers.length || 0} answers</div>
                  <div>{message.question.views.length} views</div>
                </div>
                <div className='question_mid'>
                  <div className='postTitle'>{message.question.title}</div>
                </div>
                <div className='lastActivity'>
                  <div className='question_author'>{message.question.askedBy}</div>
                  <div>&nbsp;</div>
                  <div className='question_meta'>
                    asked {getMetaData(new Date(message.question.askDateTime))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <></>
          )}
          {message.answer ? (
            <div style={{ borderTop: ' #000000 1px dashed', borderBottom: ' #000000 1px dashed' }}>
              <AnswerView
                key={String(message.answer._id)}
                text={message.answer.text}
                ansBy={message.answer.ansBy}
                meta={getMetaData(new Date(message.answer.ansDateTime))}
                comments={message.answer.comments}
                handleAddComment={(comment: Comment) => {}}
              />
            </div>
          ) : (
            <></>
          )}
          {message.msg}
        </div>
        {message.read && message.seenByAll ? (
          <div className='message-time' style={{ color: 'blue' }}>
            {`Seen by all participants: ${getMetaData(new Date(message.seenByAll))}`}
          </div>
        ) : (
          <></>
        )}
        {message.seenBy && message.seenBy.length > 0 && !message.read ? (
          <div className='message-time' style={{ color: 'blue' }}>
            {`seen by: ${message.seenBy.join(', ')}`}
          </div>
        ) : (
          <></>
        )}
      </div>
      <div
        className='reactions-list'
        style={{ display: 'flex', paddingLeft: '12.5px', paddingBottom: '10px' }}>
        <div
          className='Love-Icon'
          style={{ display: 'flex', paddingRight: '7.5px' }}
          onClick={() => {
            handleMessageUpdate(message._id, chatId, ['Love']);
          }}>
          <FaRegHeart />
          <div>{`: ${message.reactions?.filter(e => e === 'Love').length ?? 0}`}</div>
        </div>
        <div
          className='Like-Icon'
          style={{ display: 'flex', paddingRight: '7.5px' }}
          onClick={() => {
            handleMessageUpdate(message._id, chatId, ['Like']);
          }}>
          <MdOutlineThumbUp />
          <div>{`: ${message.reactions?.filter(e => e === 'Like').length ?? 0}`}</div>
        </div>
        <div
          className='Dislike-Icon'
          style={{ display: 'flex', paddingRight: '7.5px' }}
          onClick={() => {
            handleMessageUpdate(message._id, chatId, ['Dislike']);
          }}>
          <MdOutlineThumbDown />
          <div>{`: ${message.reactions?.filter(e => e === 'Dislike').length ?? 0}`}</div>
        </div>
        <div
          className='Emphathize-Icon'
          style={{ display: 'flex', paddingRight: '7.5px' }}
          onClick={() => {
            handleMessageUpdate(message._id, chatId, ['Empthaize']);
          }}>
          <LiaExclamationSolid />
          <div>{`: ${message.reactions?.filter(e => e === 'Empthaize').length ?? 0}`}</div>
        </div>
      </div>
    </>
  );
};
export default MessageCard;
