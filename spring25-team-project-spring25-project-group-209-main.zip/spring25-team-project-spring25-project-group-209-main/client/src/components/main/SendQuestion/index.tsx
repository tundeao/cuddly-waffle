import { useState } from 'react';
import { PopulatedDatabaseQuestion } from '@fake-stack-overflow/shared';
import useQuestionPage from '../../../hooks/useQuestionPage';
import CreateChatOrChooseExistingChat from '../CreateChatOrChooseExistingChat';

const SendQuestion = () => {
  const { qlist } = useQuestionPage();

  const [chosenQuestion, setChosenQuestion] = useState<PopulatedDatabaseQuestion | undefined>(
    undefined,
  );
  const [showQuestionSelection, setShowQuestionSelection] = useState(true);

  return (
    <>
      <div className='create-panel'>
        <h2>{`Choose a Question: ${chosenQuestion?.title ?? ''} `}</h2>
        <button
          className='custom-button'
          onClick={() => setShowQuestionSelection(!showQuestionSelection)}>
          {showQuestionSelection ? 'Hide Question Selection' : 'Show Question Selection'}
        </button>
        {showQuestionSelection && (
          <div id='question_list' style={{ borderTop: ' #000000 1px dashed' }}>
            {qlist.map(question => (
              <div
                onClick={() => {
                  setChosenQuestion(question);
                  setShowQuestionSelection(false);
                }}
                key={question.title}
                style={{ borderBottom: ' #000000 1px dashed', padding: '10px' }}>
                <div className='question_mid'>
                  <div className='postTitle'>{question.title}</div>
                  <div>{question.text}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <CreateChatOrChooseExistingChat question={chosenQuestion} />
    </>
  );
};

export default SendQuestion;
