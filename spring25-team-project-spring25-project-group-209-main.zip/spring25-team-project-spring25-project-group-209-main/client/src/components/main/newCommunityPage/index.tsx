import React from 'react';
import useNewCommunity from '../../../hooks/useNewCommunity';
import Form from '../baseComponents/form';
import Input from '../baseComponents/input';
import TextArea from '../baseComponents/textarea';

/**
 * NewCommunityPage component allows users to submit a new community with a title,
 * description, tags (optional).
 */
const NewCommunityPage = () => {
  const {
    title,
    setTitle,
    description,
    setDescription,
    tagNames,
    setTagNames,
    titleErr,
    descriptionErr,
    tagErr,
    postCommunity,
  } = useNewCommunity();

  return (
    <Form>
      <Input
        title={'Community Title'}
        hint={'Limit title to 100 characters or less'}
        id={'formTitleInput'}
        val={title}
        setState={setTitle}
        err={titleErr}
      />
      <TextArea
        title={'Community Description'}
        hint={'Add details'}
        id={'formTextInput'}
        val={description}
        setState={setDescription}
        err={descriptionErr}
      />
      <Input
        title={'Tags'}
        hint={'Add keywords separated by whitespace'}
        id={'formTagInput'}
        mandatory={false}
        val={tagNames}
        setState={setTagNames}
        err={tagErr}
      />
      <div className='btn_indicator_container'>
        <button
          className='form_postBtn'
          onClick={() => {
            postCommunity();
          }}>
          Add Community
        </button>
        <div className='mandatory_indicator'>* indicates mandatory fields</div>
      </div>
    </Form>
  );
};

export default NewCommunityPage;
