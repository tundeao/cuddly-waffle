import { useState } from 'react';
import { PopulatedDatabaseAnswer } from '@fake-stack-overflow/shared';
import CreateChatOrChooseExistingChat from '../CreateChatOrChooseExistingChat';
import useAnswerPage from '../../../hooks/useAnswerPage';

const SendAnswer = () => {
  const { question } = useAnswerPage();

  const [chosenAnswer, setChosenAnswer] = useState<PopulatedDatabaseAnswer | undefined>(undefined);
  const [showQuestionSelection, setShowQuestionSelection] = useState(true);

  return (
    <>
      <div className='create-panel'>
        <h2>{`Choose an Answer: ${chosenAnswer?.text ?? ''} `}</h2>
        <button
          className='custom-button'
          onClick={() => setShowQuestionSelection(!showQuestionSelection)}>
          {showQuestionSelection ? 'Hide Answer Selection' : 'Show Answer Selection'}
        </button>
        {showQuestionSelection && (
          <div id='answer_list' style={{ borderTop: ' #000000 1px dashed' }}>
            {question?.answers.map(answer => (
              <div
                onClick={() => {
                  setChosenAnswer(answer);
                  setShowQuestionSelection(false);
                }}
                key={answer.text}
                style={{ borderBottom: ' #000000 1px dashed', padding: '10px' }}>
                <div className='question_mid'>
                  <div className='postTitle'>{answer.text}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <CreateChatOrChooseExistingChat answer={chosenAnswer} />
    </>
  );
};

export default SendAnswer;
