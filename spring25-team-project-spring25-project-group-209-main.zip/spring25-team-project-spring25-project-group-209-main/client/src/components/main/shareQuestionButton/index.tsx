import React from 'react';
import { useNavigate } from 'react-router-dom';

/**
 * AskQuestionButton component that renders a button for navigating to the
 * "New Question" page. When clicked, it redirects the user to the page
 * where they can ask a new question.
 */
const ShareQuestionButton = () => {
  const navigate = useNavigate();

  /**
   * Function to handle navigation to the "New Question" page.
   */
  const handleShareQuestion = () => {
    navigate('/share/question');
  };

  return (
    <button
      className='bluebtn'
      onClick={() => {
        handleShareQuestion();
      }}>
      Share a Question
    </button>
  );
};

export default ShareQuestionButton;
