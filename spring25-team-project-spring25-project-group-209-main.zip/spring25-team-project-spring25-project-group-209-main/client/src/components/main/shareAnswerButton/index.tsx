import React from 'react';
import { useNavigate } from 'react-router-dom';

/**
 * AskQuestionButton component that renders a button for navigating to the
 * "New Question" page. When clicked, it redirects the user to the page
 * where they can ask a new question.
 */
interface ShareAnswerButtonProps {
  questionID?: string;
}
const ShareAnswerButton = (props: ShareAnswerButtonProps) => {
  const { questionID } = props;

  const navigate = useNavigate();

  /**
   * Function to handle navigation to the "New Question" page.
   */
  const handleShareAnswer = () => {
    navigate(`/share/answer/${questionID}`);
  };

  return (
    <button
      className='bluebtn'
      onClick={() => {
        handleShareAnswer();
      }}>
      Share an Answer
    </button>
  );
};

export default ShareAnswerButton;
