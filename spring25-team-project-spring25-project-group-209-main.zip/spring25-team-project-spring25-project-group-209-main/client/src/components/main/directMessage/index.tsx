import React from 'react';
import './index.css';
import useDirectMessage from '../../../hooks/useDirectMessage';
import ChatsListCard from './chatsListCard';
import UsersListPage from '../usersListPage';
import MessageCardExtension from '../messageCardExtension';

/**
 * DirectMessage component renders a page for direct messaging between users.
 * It includes a list of users and a chat window to send and receive messages.
 */
const DirectMessage = () => {
  const {
    selectedChat,
    chatToCreate,
    chats,
    newMessage,
    setNewMessage,
    showCreatePanel,
    setShowCreatePanel,
    handleSendMessage,
    handleChatSelect,
    handleUserSelect,
    handleCreateChat,
    showRemovePanel,
    setShowRemovePanel,
    handleRemoveUsers,
    userToRemove,
    setUserToRemove,
    handleAddUsers,
    showAddPanel,
    setShowAddPanel,
    setUserToAdd,
    userToAdd,
    setChatToCreate,
    selectedMessage,
    setSelectedMessage,
    handleMessageUpdate,
    error,
  } = useDirectMessage();

  return (
    <>
      <div className='create-panel'>
        <button
          className='custom-button'
          onClick={() => {
            setShowCreatePanel(prevState => !prevState);
            setChatToCreate([]);
          }}>
          {showCreatePanel ? 'Hide Create Chat Panel' : 'Start a Chat'}
        </button>
        {error && <div className='direct-message-error'>{error}</div>}
        {showCreatePanel && (
          <>
            <p>Selected users: {chatToCreate.join(', ')}</p>
            <button className='custom-button' onClick={handleCreateChat}>
              Create New Chat
            </button>
            <UsersListPage handleUserSelect={handleUserSelect} />
          </>
        )}
      </div>
      <div className='direct-message-container'>
        <div className='chats-list'>
          {chats.map(chat => (
            <ChatsListCard key={String(chat._id)} chat={chat} handleChatSelect={handleChatSelect} />
          ))}
        </div>
        <div className='chat-container'>
          {selectedChat ? (
            <>
              <div>
                <h2>Chat Participants: {selectedChat.participants.join(', ')}</h2>
                {selectedChat.participants.length > 2 ? (
                  <button
                    style={{ display: 'inline-block' }}
                    className='custom-button'
                    onClick={() => setShowRemovePanel(prevState => !prevState)}>
                    {showRemovePanel ? 'Hide Remove User Panel' : 'Remove a User'}
                  </button>
                ) : (
                  <></>
                )}
                {error && <div className='direct-message-error'>{error}</div>}
                {showRemovePanel && (
                  <>
                    <p>Selected user: {userToRemove}</p>
                    <button
                      className='custom-button'
                      disabled={userToRemove === '' || selectedChat.participants.length <= 2}
                      onClick={() => {
                        if (userToRemove && userToRemove !== '') handleRemoveUsers(userToRemove);
                      }}>
                      Remove User
                    </button>
                    {selectedChat.participants.map(user => (
                      <div
                        key={user}
                        className='user right_padding'
                        onClick={() => setUserToRemove(user)}>
                        <div className='user_mid'>
                          <div className='userUsername'>{user}</div>
                        </div>
                      </div>
                    ))}
                  </>
                )}
                <button
                  style={{ display: 'inline-block' }}
                  className='custom-button'
                  onClick={() => setShowAddPanel(prevState => !prevState)}>
                  {showAddPanel ? 'Hide Add User Panel' : 'Add a User'}
                </button>

                {error && <div className='direct-message-error'>{error}</div>}
                {showAddPanel && (
                  <>
                    <p>Selected user: {userToAdd?.username}</p>
                    <button
                      className='custom-button'
                      disabled={userToAdd === undefined}
                      onClick={() => {
                        if (userToAdd) handleAddUsers(userToAdd);
                      }}>
                      Add User
                    </button>
                    <div style={{ overflow: 'scroll', height: '300px' }}>
                      <UsersListPage
                        handleUserSelect={user => {
                          setUserToAdd(user);
                        }}
                      />
                    </div>
                  </>
                )}
              </div>
              <div className='chat-messages'>
                {selectedChat.messages.map(message => (
                  <MessageCardExtension
                    handleMessageUpdate={handleMessageUpdate}
                    chatId={selectedChat._id}
                    key={String(message._id)}
                    message={message}
                    selectedMessage={selectedMessage}
                    setSelectedMessage={setSelectedMessage}
                  />
                ))}
              </div>
              <div className='message-input'>
                <input
                  className='custom-input'
                  type='text'
                  value={newMessage}
                  onChange={e => setNewMessage(e.target.value)}
                  placeholder='Type a message...'
                />
                <button
                  className='custom-button'
                  onClick={() => {
                    handleSendMessage();
                  }}>
                  Send
                </button>
              </div>
            </>
          ) : (
            <h2>Select a user to start chatting</h2>
          )}
        </div>
      </div>
    </>
  );
};

export default DirectMessage;
