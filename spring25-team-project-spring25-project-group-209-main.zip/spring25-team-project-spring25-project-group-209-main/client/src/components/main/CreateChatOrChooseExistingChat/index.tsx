import { useState } from 'react';
import {
  Comment,
  PopulatedDatabaseAnswer,
  PopulatedDatabaseQuestion,
} from '@fake-stack-overflow/shared';
import { useNavigate } from 'react-router-dom';
import useDirectMessage from '../../../hooks/useDirectMessage';
import ChatsListCard from '../directMessage/chatsListCard';
import UsersListPage from '../usersListPage';
import QuestionView from '../questionPage/question';
import AnswerView from '../answerPage/answer';
import { getMetaData } from '../../../tool';

interface CreateChatOrChooseExistingChatProps {
  question?: PopulatedDatabaseQuestion | undefined;
  answer?: PopulatedDatabaseAnswer | undefined;
}

const CreateChatOrChooseExistingChat = (props: CreateChatOrChooseExistingChatProps) => {
  const {
    handleSendMessage,
    handleCreateChatWithMessage,
    chats,
    chatToCreate,
    handleChatSelect,
    setShowCreatePanel,
    showCreatePanel,
    error,
    newMessage,
    setNewMessage,
    selectedChat,
    handleUserSelect,
  } = useDirectMessage();

  const { question, answer } = props;
  const [showExistingChat, setShowExistingChat] = useState(false);

  const [showNewChatSend, setShowNewChatSend] = useState(false);

  const navigate = useNavigate();

  const handleBackToQuestionPage = () => {
    navigate('/messaging/direct-message');
  };
  return (
    <>
      <div>
        <div className='create-panel'>
          <button
            className='custom-button'
            disabled={!question && !answer}
            onClick={() => setShowExistingChat(!showExistingChat)}>
            {showExistingChat ? 'Hide Share with Chat Panel' : 'Share with Existing Chat'}
          </button>
          <button
            className='custom-button'
            disabled={!question && !answer}
            onClick={() => setShowCreatePanel(prevState => !prevState)}>
            {showCreatePanel ? 'Hide Create Chat Panel' : 'Start a Chat'}
          </button>
          {showExistingChat ? (
            <div>
              <div style={{ display: 'flex', flexDirection: 'row' }}>
                <div className='chats-list'>
                  <h2>{`Selected Chat: ${selectedChat != null ? selectedChat.participants.join(', ') : ''} `}</h2>
                  {chats.map(chat => (
                    <div key={String(chat._id)}>
                      <ChatsListCard
                        key={String(chat._id)}
                        chat={chat}
                        handleChatSelect={() => {
                          handleChatSelect(chat._id);
                        }}
                      />
                    </div>
                  ))}
                </div>
                {question ? <QuestionView question={question} /> : <></>}
                {answer ? (
                  <AnswerView
                    key={String(answer._id)}
                    text={answer.text}
                    ansBy={answer.ansBy}
                    meta={getMetaData(new Date(answer.ansDateTime))}
                    comments={answer.comments}
                    handleAddComment={(comment: Comment) => {}}
                  />
                ) : (
                  <></>
                )}
              </div>
              <div className='message-input'>
                <input
                  className='custom-input'
                  type='text'
                  value={newMessage}
                  onChange={e => setNewMessage(e.target.value)}
                  placeholder='Type a message...'
                />
                <button
                  className='custom-button'
                  disabled={newMessage === '' || selectedChat == null}
                  onClick={() => {
                    handleSendMessage(question?._id, answer?._id);
                    handleBackToQuestionPage();
                  }}>
                  Send
                </button>
              </div>
            </div>
          ) : (
            <></>
          )}
          {error && <div className='direct-message-error'>{error}</div>}
          {showCreatePanel && !showNewChatSend && (
            <>
              <p>Selected users: {chatToCreate.join(', ')}</p>
              <button
                className='custom-button'
                onClick={() => {
                  setShowNewChatSend(true);
                }}>
                Create New Chat
              </button>
              <UsersListPage handleUserSelect={handleUserSelect} />
            </>
          )}
          {showNewChatSend && (
            <>
              {question ? <QuestionView question={question} /> : <></>}
              {answer ? (
                <AnswerView
                  key={String(answer._id)}
                  text={answer.text}
                  ansBy={answer.ansBy}
                  meta={getMetaData(new Date(answer.ansDateTime))}
                  comments={answer.comments}
                  handleAddComment={(comment: Comment) => {}}
                />
              ) : (
                <></>
              )}
              <h2>{`Create a Chat With: ${chatToCreate}`}</h2>
              <div className='message-input'>
                <input
                  className='custom-input'
                  type='text'
                  value={newMessage}
                  onChange={e => setNewMessage(e.target.value)}
                  placeholder='Type a message...'
                />
                <button
                  className='custom-button'
                  disabled={newMessage === ''}
                  onClick={() => {
                    handleCreateChatWithMessage(question?._id, answer?._id);
                    handleBackToQuestionPage();
                  }}>
                  Send
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default CreateChatOrChooseExistingChat;
