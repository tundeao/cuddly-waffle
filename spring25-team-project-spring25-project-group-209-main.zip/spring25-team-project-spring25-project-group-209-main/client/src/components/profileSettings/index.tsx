import React from 'react';
import './index.css';
import useProfileSettings from '../../hooks/useProfileSettings';
import CommunitiesListHeader from '../main/communityPage/communityHeader';
import useCommunityListPage from '../../hooks/useCommunityListPage';

const ProfileSettings: React.FC = () => {
  const {
    userData,
    loading,
    editBioMode,
    newBio,
    newPassword,
    confirmNewPassword,
    successMessage,
    errorMessage,
    showConfirmation,
    pendingAction,
    canEditProfile,
    showPassword,
    togglePasswordVisibility,

    setEditBioMode,
    setNewBio,
    setNewPassword,
    setConfirmNewPassword,
    setShowConfirmation,

    handleResetPassword,
    handleUpdateBiography,
    handleDeleteUser,
    handleAddCommunity,
    addedCommunity,
    setAddedCommunity,
    handleJoinOtherUserCommunity,
    currentLoginUser,
  } = useProfileSettings();
  const { filteredCommunitylist, setCommunityFilter } = useCommunityListPage();

  if (loading) {
    return (
      <div className='page-container'>
        <div className='profile-card'>
          <h2>Loading user data...</h2>
        </div>
      </div>
    );
  }

  // Helper function to get badge icon based on badge level
  const getBadgeIcon = (badgeTitle: string) => {
    if (badgeTitle.includes('Bronze')) return '🥉';
    if (badgeTitle.includes('Silver')) return '🥈';
    if (badgeTitle.includes('Gold')) return '🥇';
    return '🏆';
  };

  return (
    <div className='page-container'>
      <div className='profile-card'>
        <h2>Profile</h2>
        {successMessage && <p className='success-message'>{successMessage}</p>}
        {errorMessage && <p className='error-message'>{errorMessage}</p>}
        {userData ? (
          <>
            <h4>General Information</h4>
            <p>
              <strong>Username:</strong> {userData.username}
            </p>

            {/* ---- Biography Section ---- */}
            {!editBioMode && (
              <p>
                <strong>Biography:</strong> {userData.biography || 'No biography yet.'}
                {canEditProfile && (
                  <button
                    className='login-button'
                    style={{ marginLeft: '1rem' }}
                    onClick={() => {
                      setEditBioMode(true);
                      setNewBio(userData.biography || '');
                    }}>
                    Edit
                  </button>
                )}
              </p>
            )}
            {/* ---- Communities Section ---- */}
            {currentLoginUser && (
              <div className='community-list-section'>
                <strong>Joined communities:</strong>
                {userData.interests?.map((community, index) => (
                  <div key={index} className='community-item'>
                    <p>{community.title}</p>
                    {!canEditProfile &&
                      !currentLoginUser.interests
                        ?.map(interest => interest.title)
                        .includes(community.title) && (
                        <button onClick={() => handleJoinOtherUserCommunity(community.title)}>
                          Join
                        </button>
                      )}
                  </div>
                )) || 'No communities joined yet.'}
              </div>
            )}
            {editBioMode && canEditProfile && (
              <div style={{ margin: '1rem 0' }}>
                <input
                  className='input-text'
                  type='text'
                  value={newBio}
                  onChange={e => setNewBio(e.target.value)}
                />
                <button
                  className='login-button'
                  style={{ marginLeft: '1rem' }}
                  onClick={handleUpdateBiography}>
                  Save
                </button>
                <button
                  className='delete-button'
                  style={{ marginLeft: '1rem' }}
                  onClick={() => setEditBioMode(false)}>
                  Cancel
                </button>
              </div>
            )}
            <p>
              <strong>Date Joined:</strong>{' '}
              {userData.dateJoined ? new Date(userData.dateJoined).toLocaleDateString() : 'N/A'}
            </p>
            {/* ---- Badges Section ---- */}
            <div className='badges-section'>
              <h4>Badges</h4>
              {userData.badges && userData.badges.length > 0 ? (
                <div className='badges-grid'>
                  {userData.badges.map((badge, index) => (
                    <div key={index} className='badge-icon-container'>
                      <span className='badge-icon' title={badge.title}>
                        {getBadgeIcon(badge.title)}
                      </span>
                      <div className='badge-tooltip'>
                        <h5 className='badge-title'>{badge.title}</h5>
                        <p className='badge-description'>{badge.description}</p>
                        <p className='badge-date'>
                          Awarded: {new Date(badge.dateAwarded).toLocaleDateString()}
                        </p>
                        <p className='badge-type'>
                          Type: {badge.type.charAt(0).toUpperCase() + badge.type.slice(1)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p>No badges earned yet. Contribute to earn badges!</p>
              )}
            </div>
            {/* ---- Reset Password Section ---- */}
            {canEditProfile && (
              <>
                <div className='community-list-container'>
                  <h4>Add Community</h4>
                  <CommunitiesListHeader
                    communityCount={filteredCommunitylist.length}
                    setCommunityFilter={setCommunityFilter}
                  />
                  {filteredCommunitylist.slice(0, 3)?.map((community, index) => (
                    <p
                      className={`community-item ${addedCommunity === community.title ? 'selected' : ''}`}
                      onClick={() => setAddedCommunity(community.title)}
                      key={index}>
                      {community.title}
                    </p>
                  ))}
                  <button onClick={handleAddCommunity} className='commmunity-button'>
                    Add Community
                  </button>
                </div>
                <h4>Reset Password</h4>
                <input
                  className='input-text'
                  type={showPassword ? 'text' : 'password'}
                  placeholder='New Password'
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                />
                <input
                  className='input-text'
                  type={showPassword ? 'text' : 'password'}
                  placeholder='Confirm New Password'
                  value={confirmNewPassword}
                  onChange={e => setConfirmNewPassword(e.target.value)}
                />
                <button className='toggle-password-button' onClick={togglePasswordVisibility}>
                  {showPassword ? 'Hide Passwords' : 'Show Passwords'}
                </button>
                <button className='login-button' onClick={handleResetPassword}>
                  Reset
                </button>
              </>
            )}
            {/* ---- Danger Zone (Delete User) ---- */}
            {canEditProfile && (
              <>
                <h4>Danger Zone</h4>
                <button className='delete-button' onClick={handleDeleteUser}>
                  Delete This User
                </button>
              </>
            )}
            <p>
              <strong>Date Joined:</strong>{' '}
              {userData.dateJoined ? new Date(userData.dateJoined).toLocaleDateString() : 'N/A'}
            </p>
          </>
        ) : (
          <p>No user data found. Make sure the username parameter is correct.</p>
        )}
        {/* ---- Confirmation Modal for Delete ---- */}
        {showConfirmation && (
          <div className='modal'>
            <div className='modal-content'>
              <p>
                Are you sure you want to delete user <strong>{userData?.username}</strong>? This
                action cannot be undone.
              </p>
              <button className='delete-button' onClick={() => pendingAction && pendingAction()}>
                Confirm
              </button>
              <button className='cancel-button' onClick={() => setShowConfirmation(false)}>
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfileSettings;
