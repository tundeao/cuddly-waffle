import { PopulatedDatabaseQuestion } from './question';
import { PopulatedDatabaseAnswer } from './answer';

/**
 * Represents a post made, either question or answer stored in the database
 */
export type PopulatedDatabasePost = PopulatedDatabaseQuestion | PopulatedDatabaseAnswer;
