// // Run this script to launch the server.

import {server, app, startServer} from './app'

startServer();
export {app, server};


