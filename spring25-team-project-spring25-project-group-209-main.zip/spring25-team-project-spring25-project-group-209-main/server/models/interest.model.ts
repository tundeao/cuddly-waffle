import mongoose, { Model } from 'mongoose';
import interestSchema from './schema/interest.schema';
import { DatabaseInterest } from '../types/types';

/**
 * Mongoose model for the `Interest` collection.
 *
 * This model is created using the `Interest` interface and the `interestSchema`, representing the
 * `Interest` collection in the MongoDB database, and provides an interface for interacting with
 * the stored interests.
 *
 * @type {Model<DatabaseInterest>}
 */
const InterestModel: Model<DatabaseInterest> = mongoose.model<DatabaseInterest>(
  'Interest',
  interestSchema,
);

export default InterestModel;
