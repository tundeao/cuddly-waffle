import { Schema } from 'mongoose';

/**
 * Mongoose schema for the Interest collection.
 *
 *
 * This schema defines the structure for storing interests in the database.
 * Each Interest includes the following fields:
 * - `title`: The name of the interest.
 * - `description`: The description of the interest.
 * - `tags`: The tags (common attributes) associated to an interest.
 */
const interestSchema: Schema = new Schema(
  {
    title: {
      type: String,
      unique: true,
      required: true,
    },
    description: {
      type: String,
      required: true,
    },
    tags: {
      type: [String],
    },
  },
  { collection: 'Interest' },
);

export default interestSchema;
