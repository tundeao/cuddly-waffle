import { Schema } from 'mongoose';

/**
 * Badge schema definition
 */
const badgeSchema = new Schema({
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  type: {
    type: String,
    enum: ['question', 'answer'],
    required: true,
  },
  dateAwarded: {
    type: Date,
    default: Date.now,
    required: true,
  },
});

/**
 * User schema definition
 */
const userSchema = new Schema({
  username: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  dateJoined: {
    type: Date,
    default: Date.now,
    required: true,
  },
  biography: {
    type: String,
    default: '',
  },
  badges: {
    type: [badgeSchema],
    default: [],
  },
  interests: [
    {
      type: Schema.Types.ObjectId,
      ref: 'Interest',
    },
  ],
});

export default userSchema;
