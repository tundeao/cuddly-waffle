import express, { Request, Response, Router } from 'express';
import {
  UserRequest,
  User,
  UserCredentials,
  UserByUsernameRequest,
  FakeSOSocket,
  UpdateBiographyRequest,
  UpdateBadgeRequest,
  UpdateInterestRequest,
  DatabaseInterest,
  FindUsersByInterest,
  PopulatedDatabaseUser,
} from '../types/types';
import {
  deleteUserByUsername,
  getUserBadgeByDescription,
  getUserByUsername,
  getUsersList,
  loginUser,
  saveUser,
  updateUser,
  updateUserInterest,
  getUsersByInterest,
} from '../services/user.service';
import { getInterestByTitle } from '../services/interest.service';
import { populateDocument } from '../utils/database.util';

const userController = (socket: FakeSOSocket) => {
  const router: Router = express.Router();

  /**
   * Validates that the request body contains all required fields for a user.
   * @param req The incoming request containing user data.
   * @returns `true` if the body contains valid user fields; otherwise, `false`.
   */
  const isUserBodyValid = (req: UserRequest): boolean =>
    req.body !== undefined &&
    req.body.username !== undefined &&
    req.body.username !== '' &&
    req.body.password !== undefined &&
    req.body.password !== '';

  /**
   * Validates that the request body contains all required fields to update a biography.
   * @param req The incoming request containing user data.
   * @returns `true` if the body contains valid user fields; otherwise, `false`.
   */
  const isUpdateBiographyBodyValid = (req: UpdateBiographyRequest): boolean =>
    req.body !== undefined &&
    req.body.username !== undefined &&
    req.body.username.trim() !== '' &&
    req.body.biography !== undefined;

  /**
   * Validates that the request body contains all required fields for adding a badge.
   * @param req The incoming request containing badge data.
   * @returns `true` if the body contains valid badge fields; otherwise, `false`.
   */
  const isUpdateBadgeBodyValid = (req: UpdateBadgeRequest): boolean =>
    req.body !== undefined &&
    req.body.username !== undefined &&
    req.body.username.trim() !== '' &&
    req.body.badgeTitle !== undefined &&
    req.body.badgeTitle.trim() !== '' &&
    req.body.badgeDescription !== undefined &&
    req.body.badgeType !== undefined &&
    (req.body.badgeType === 'question' || req.body.badgeType === 'answer') &&
    (req.body.action === 'add' || req.body.action === 'remove');

  /**
   * Validates that the request body contains all required fields to update interest list.
   * @param req The incoming request containing user data.
   * @returns `true` if the body contains valid user fields; otherwise, `false`.
   */
  const isUpdateInterestBodyValid = (req: UpdateInterestRequest): boolean =>
    req.body !== undefined &&
    req.body.username !== undefined &&
    req.body.username.trim() !== '' &&
    req.body.interestTitle !== undefined &&
    req.body.interestTitle !== '' &&
    req.body.action !== undefined &&
    (req.body.action === 'join' || req.body.action === 'leave');

  /**
   * Handles the creation of a new user account.
   * @param req The request containing username, email, and password in the body.
   * @param res The response, either returning the created user or an error.
   * @returns A promise resolving to void.
   */
  const createUser = async (req: UserRequest, res: Response): Promise<void> => {
    if (!isUserBodyValid(req)) {
      res.status(400).send('Invalid user body');
      return;
    }

    const requestUser = req.body;

    const user: User = {
      ...requestUser,
      dateJoined: new Date(),
      biography: requestUser.biography ?? '',
    };

    try {
      const result = await saveUser(user);

      if ('error' in result) {
        throw new Error(result.error);
      }

      socket.emit('userUpdate', {
        user: result,
        type: 'created',
      });
      res.status(200).json(result);
    } catch (error) {
      res.status(500).send(`Error when saving user: ${error}`);
    }
  };

  /**
   * Handles user login by validating credentials.
   * @param req The request containing username and password in the body.
   * @param res The response, either returning the user or an error.
   * @returns A promise resolving to void.
   */
  const userLogin = async (req: UserRequest, res: Response): Promise<void> => {
    try {
      if (!isUserBodyValid(req)) {
        res.status(400).send('Invalid user body');
        return;
      }

      const loginCredentials: UserCredentials = {
        username: req.body.username,
        password: req.body.password,
      };

      const user = await loginUser(loginCredentials);

      if ('error' in user) {
        throw Error(user.error);
      }

      res.status(200).json(user);
    } catch (error) {
      res.status(500).send('Login failed');
    }
  };

  /**
   * Retrieves a user by their username.
   * @param req The request containing the username as a route parameter.
   * @param res The response, either returning the user or an error.
   * @returns A promise resolving to void.
   */
  const getUser = async (req: UserByUsernameRequest, res: Response): Promise<void> => {
    try {
      const { username } = req.params;

      const user = await getUserByUsername(username);

      if ('error' in user) {
        throw Error(user.error);
      }

      const populatedUser = await populateDocument(user._id.toString(), 'user');

      if (populatedUser && 'error' in populatedUser) {
        throw new Error(populatedUser.error);
      }

      res.status(200).json(populatedUser);
    } catch (error) {
      res.status(500).send(`Error when getting user by username: ${error}`);
    }
  };

  /**
   * Retrieves all users from the database.
   * @param res The response, either returning the users or an error.
   * @returns A promise resolving to void.
   */
  const getUsers = async (_: Request, res: Response): Promise<void> => {
    try {
      const users = await getUsersList();

      if ('error' in users) {
        throw Error(users.error);
      }

      res.status(200).json(users);
    } catch (error) {
      res.status(500).send(`Error when getting users: ${error}`);
    }
  };

  /**
   * Deletes a user by their username.
   * @param req The request containing the username as a route parameter.
   * @param res The response, either confirming deletion or returning an error.
   * @returns A promise resolving to void.
   */
  const deleteUser = async (req: UserByUsernameRequest, res: Response): Promise<void> => {
    try {
      const { username } = req.params;

      const deletedUser = await deleteUserByUsername(username);

      if ('error' in deletedUser) {
        throw Error(deletedUser.error);
      }

      socket.emit('userUpdate', {
        user: deletedUser,
        type: 'deleted',
      });
      res.status(200).json(deletedUser);
    } catch (error) {
      res.status(500).send(`Error when deleting user by username: ${error}`);
    }
  };

  /**
   * Resets a user's password.
   * @param req The request containing the username and new password in the body.
   * @param res The response, either confirming the update or returning an error.
   * @returns A promise resolving to void.
   */
  const resetPassword = async (req: UserRequest, res: Response): Promise<void> => {
    try {
      if (!isUserBodyValid(req)) {
        res.status(400).send('Invalid user body');
        return;
      }

      const updatedUser = await updateUser(req.body.username, { password: req.body.password });

      if ('error' in updatedUser) {
        throw Error(updatedUser.error);
      }

      res.status(200).json(updatedUser);
    } catch (error) {
      res.status(500).send(`Error when updating user password: ${error}`);
    }
  };

  /**
   * Updates a user's biography.
   * @param req The request containing the username and biography in the body.
   * @param res The response, either confirming the update or returning an error.
   * @returns A promise resolving to void.
   */
  const updateBiography = async (req: UpdateBiographyRequest, res: Response): Promise<void> => {
    try {
      if (!isUpdateBiographyBodyValid(req)) {
        res.status(400).send('Invalid user body');
        return;
      }

      // Validate that request has username and biography
      const { username, biography } = req.body;

      // Call the same updateUser(...) service used by resetPassword
      const updatedUser = await updateUser(username, { biography });

      if ('error' in updatedUser) {
        throw new Error(updatedUser.error);
      }

      // Emit socket event for real-time updates
      socket.emit('userUpdate', {
        user: updatedUser,
        type: 'updated',
      });

      res.status(200).json(updatedUser);
    } catch (error) {
      res.status(500).send(`Error when updating user biography: ${error}`);
    }
  };

  /**
   * Updates a user's badges (adding or removing a badge).
   * @param req The request containing the username, badge details, and action in the body.
   * @param res The response, either confirming the update or returning an error.
   * @returns A promise resolving to void.
   */
  const updateBadge = async (req: UpdateBadgeRequest, res: Response): Promise<void> => {
    try {
      if (!isUpdateBadgeBodyValid(req)) {
        res.status(400).send('Invalid badge request body');
        return;
      }

      const { username, badgeTitle, badgeDescription, badgeType, action } = req.body;

      // Create a proper Date object for dateAwarded
      let dateAwarded = new Date();
      if (req.body.dateAwarded) {
        // If dateAwarded is provided, ensure it's a proper Date object
        dateAwarded = new Date(req.body.dateAwarded);
        if (Number.isNaN(dateAwarded.getTime())) {
          // If invalid date, use current date
          dateAwarded = new Date();
        }
      }

      const badge = {
        title: badgeTitle,
        description: badgeDescription,
        type: badgeType,
        dateAwarded,
      };

      const currentUser = await getUserByUsername(username);

      if ('error' in currentUser) {
        res.status(404).send(`User not found: ${username}`);
        return;
      }

      const currentBadges = currentUser.badges || [];

      // Check if badge already exists for 'add' action
      if (action === 'add' && currentBadges.some(b => b.description === badgeDescription)) {
        res.status(200).json(currentUser); // Return success but don't duplicate
        return;
      }

      // Check if badge exists for 'remove' action
      if (action === 'remove' && !currentBadges.some(b => b.description === badgeDescription)) {
        res.status(200).json(currentUser); // Return success but nothing to remove
        return;
      }

      let updatedUser;
      if (action === 'add') {
        updatedUser = await updateUser(username, { badges: [...currentBadges, badge] });
      } else {
        const updatedBadges = currentBadges.filter(
          currBadge => currBadge.description !== badgeDescription,
        );
        updatedUser = await updateUser(username, { badges: updatedBadges });
      }

      if ('error' in updatedUser) {
        throw new Error(updatedUser.error);
      }

      // Emit socket event for real-time updates
      socket.emit('userUpdate', {
        user: updatedUser,
        type: 'updated',
      });

      res.status(200).json(updatedUser);
    } catch (error) {
      res.status(500).send(`Error when updating user badges: ${error}`);
    }
  };

  /**
   * Retrieves a specific badge by its title for a given user.
   * @param req The request containing the username and badge title as route parameters.
   * @param res The response, either returning the badge or an error.
   * @returns A promise resolving to void.
   */
  const getBadgeByDescription = async (req: Request, res: Response): Promise<void> => {
    try {
      const { username, badgeDescription } = req.params;

      if (!username || !badgeDescription) {
        res.status(400).send('Username and badge title are required');
        return;
      }

      const badge = await getUserBadgeByDescription(username, badgeDescription);

      if ('error' in badge) {
        throw Error(badge.error);
      }

      res.status(200).json(badge);
    } catch (error) {
      res.status(500).send(`Error when getting badge by title: ${error}`);
    }
  };

  /**
   * Updates a user's interest list. Incoming request has an interest title. Either will add or remove based on action (join/leave).
   * @param req The request containing the username, interest, and action in the body.
   * @param res The response, either confirming the update or returning an error.
   * @returns A promise resolving to void.
   */
  const updateInterests = async (req: UpdateInterestRequest, res: Response): Promise<void> => {
    try {
      if (!isUpdateInterestBodyValid(req)) {
        res.status(400).send('Invalid user body');
        return;
      }
      const { username, interestTitle, action } = req.body;

      // Try retrieving interest in DB
      const existingInterest = await getInterestByTitle(interestTitle);
      if ('error' in existingInterest) {
        if (existingInterest.error.includes('Interest not found')) {
          res.status(404).send('Interest not found.');
          return;
        }
        throw new Error(existingInterest.error);
      }

      // Check user's existing interests.
      const user = await getUserByUsername(username);

      if ('error' in user) {
        throw new Error(user.error);
      }

      const userInterestsId = user.interests?.map(obj => obj._id.toString());
      // If user wants to join, check if interest doesn't exist. Otherwise, return error.
      if (
        action === 'join' &&
        userInterestsId?.includes((existingInterest as DatabaseInterest)._id.toString())
      ) {
        res.status(400).send('User already has this interest.');
        return;
      }

      // If user wants to leave, check if interest exists. Otherwise, return error.
      if (
        action === 'leave' &&
        !userInterestsId?.includes((existingInterest as DatabaseInterest)._id.toString())
      ) {
        res.status(400).send('User does not have this interest.');
        return;
      }

      const updatedUser = await updateUserInterest(
        username,
        (existingInterest as DatabaseInterest)._id.toString(),
        action,
      );

      if ('error' in updatedUser) {
        throw new Error(updatedUser.error);
      }

      const populatedUser = await populateDocument(updatedUser._id.toString(), 'user');

      if (populatedUser && 'error' in populatedUser) {
        throw new Error(populatedUser.error);
      }

      // Emit socket event for real-time updates
      socket.emit('userUpdate', {
        user: populatedUser as PopulatedDatabaseUser,
        type: 'updated',
      });

      res.status(200).json(populatedUser);
    } catch (error) {
      res.status(500).send(`Error when updating user interest: ${error}`);
    }
  };

  /**
   * Retrieves all users with a specific interest.
   * @param res The response, either returning the users or an error.
   * @returns A promise resolving to void.
   */
  const getUsersByInterestRoute = async (
    req: FindUsersByInterest,
    res: Response,
  ): Promise<void> => {
    const { interestTitle } = req.params;
    try {
      const existingInterest = await getInterestByTitle(interestTitle);
      if ('error' in existingInterest) {
        if (existingInterest.error.includes('Interest not found')) {
          res.status(404).send('Interest not found.');
          return;
        }
        throw new Error(existingInterest.error);
      }

      const users = await getUsersByInterest((existingInterest as DatabaseInterest)._id.toString());

      if ('error' in users) {
        throw Error(users.error);
      }

      const populatedUsers = await Promise.all(
        users.map(user => populateDocument(user._id.toString(), 'user')),
      );

      const populationError = populatedUsers.find(
        (user): user is { error: string } => 'error' in user,
      );
      if (populationError) {
        throw new Error(populationError.error);
      }

      res.status(200).json(populatedUsers);
    } catch (error) {
      res.status(500).send(`Error when getting users: ${error}`);
    }
  };

  // Define routes for the user-related operations.
  router.post('/signup', createUser);
  router.post('/login', userLogin);
  router.patch('/resetPassword', resetPassword);
  router.get('/getUser/:username', getUser);
  router.get('/getUsers', getUsers);
  router.delete('/deleteUser/:username', deleteUser);
  router.patch('/updateBiography', updateBiography);
  router.patch('/updateBadge', updateBadge);
  router.get('/getBadge/:username/:badgeDescription', getBadgeByDescription);
  router.patch('/updateInterests', updateInterests);
  router.get('/getUsersByInterest/:interestTitle', getUsersByInterestRoute);
  return router;
};

export default userController;
