import express, { Response, Request } from 'express';
import { AddInterestRequest, Interest, FakeSOSocket } from '../types/types';
import { saveInterest, getInterests } from '../services/interest.service';

const interestController = (socket: FakeSOSocket) => {
  const router = express.Router();

  /**
   * Validates the Interest object to ensure it contains the required fields.
   *
   * @param interest The interest to validate.
   *
   * @returns `true` if the interest is valid, otherwise `false`.
   */
  const isInterestValid = (interest: Interest): boolean =>
    interest.title !== undefined &&
    interest.title !== '' &&
    interest.description !== undefined &&
    interest.description !== '';

  /**
   * Handles adding a new interest. The message is first validated and then saved.
   * If the interest is invalid or saving fails, the HTTP response status is updated.
   *
   * @param req The AddInterestRequest object containing the message and chat data.
   * @param res The HTTP response object used to send back the result of the operation.
   *
   * @returns A Promise that resolves to void.
   */
  const addInterestRoute = async (req: AddInterestRequest, res: Response): Promise<void> => {
    if (!isInterestValid(req.body)) {
      res.status(400).send('Invalid interest body');
      return;
    }

    const interestToAdd: Interest = req.body;

    try {
      const interestFromDb = await saveInterest(interestToAdd);

      if ('error' in interestFromDb) {
        throw new Error(interestFromDb.error);
      }

      socket.emit('communityUpdate', interestFromDb);

      res.json(interestFromDb);
    } catch (err: unknown) {
      res.status(500).send(`Error when adding a interest: ${(err as Error).message}`);
    }
  };

  /**
   * Fetch all interests.
   * @param req The request object.
   * @param res The HTTP response object used to send back the interests.
   * @returns A Promise that resolves to void.
   */
  const getInterestRoute = async (_: Request, res: Response): Promise<void> => {
    const interests = await getInterests();
    res.json(interests);
  };

  // Add appropriate HTTP verbs and their endpoints to the router
  router.post('/addInterest', addInterestRoute);
  router.get('/getInterests', getInterestRoute);

  return router;
};

export default interestController;
