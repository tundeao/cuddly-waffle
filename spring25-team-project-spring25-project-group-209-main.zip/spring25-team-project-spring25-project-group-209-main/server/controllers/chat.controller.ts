import express, { Response } from 'express';
import {
  saveChat,
  addMessageToChat,
  getChat,
  addParticipantToChat,
  getChatsByParticipants,
  updateMessageInChat,
  removeParticipantInChat,
  addInterestToChat,
  updateMessagesInChat,
} from '../services/chat.service';
import { populateDocument } from '../utils/database.util';
import {
  FakeSOSocket,
  CreateChatRequest,
  AddMessageRequestToChat,
  AddParticipantRequest,
  ChatIdRequest,
  GetChatByParticipantsRequest,
  PopulatedDatabaseChat,
  AddInterestToChatRequest,
  DatabaseInterest,
  UpdateMessageRequestToChat,
  MessagesToUpdate,
} from '../types/types';
import { saveMessage } from '../services/message.service';
import { getInterestByTitle } from '../services/interest.service';

/*
 * This controller handles chat-related routes.
 * @param socket The socket instance to emit events.
 * @returns {express.Router} The router object containing the chat routes.
 * @throws {Error} Throws an error if the chat creation fails.
 */
const chatController = (socket: FakeSOSocket) => {
  const router = express.Router();

  /**
   * Validates that the request body contains all required fields for a chat.
   * @param req The incoming request containing chat data.
   * @returns `true` if the body contains valid chat fields; otherwise, `false`.
   */
  const isCreateChatRequestValid = (req: CreateChatRequest): boolean => {
    const { participants, messages } = req.body;
    return !!participants && Array.isArray(participants) && participants.length > 0 && !!messages;
  };

  /**
   * Validates that the request body contains all required fields for a message.
   * @param req The incoming request containing message data.
   * @returns `true` if the body contains valid message fields; otherwise, `false`.
   */
  const isAddMessageRequestValid = (req: AddMessageRequestToChat): boolean => {
    const { chatId } = req.params;
    const { msg, msgFrom } = req.body;
    return !!chatId && !!msg && !!msgFrom;
  };

  /**
   * Validates that the request body contains all required fields for a message.
   * @param req The incoming request containing message data.
   * @returns `true` if the body contains valid message fields; otherwise, `false`.
   */
  const isMessagesToUpdateValid = (req: MessagesToUpdate): boolean => {
    const { chatId } = req.params;

    return !!chatId;
  };

  const isUpdateMessageRequestValid = (req: UpdateMessageRequestToChat): boolean => {
    const { chatId } = req.params;
    const { messageId } = req.body;
    return !!chatId && !!messageId;
  };

  /**
   * Validates that the request body contains all required fields for a participant.
   * @param req The incoming request containing participant data.
   * @returns `true` if the body contains valid participant fields; otherwise, `false`.
   */
  const isUpdateParticipantRequestValid = (req: AddParticipantRequest): boolean => {
    const { chatId } = req.params;
    const { username: userId } = req.body;
    return !!chatId && !!userId;
  };

  /**
   * Validates that the request body contains all required fields for an interest.
   * @param req The incoming request containing interest data.
   * @returns `true` if the body contains valid interest fields; otherwise, `false`.
   */
  const isAddInterestRequestValid = (req: AddInterestToChatRequest): boolean => {
    const { chatId } = req.params;
    const { title } = req.body;
    return !!chatId && !!title;
  };

  /**
   * Creates a new chat with the given participants (and optional initial messages).
   * @param req The request object containing the chat data.
   * @param res The response object to send the result.
   * @returns {Promise<void>} A promise that resolves when the chat is created.
   * @throws {Error} Throws an error if the chat creation fails.
   */
  const createChatRoute = async (req: CreateChatRequest, res: Response): Promise<void> => {
    if (!req.body || !isCreateChatRequestValid(req)) {
      res.status(400).send('Invalid chat creation request');
      return;
    }

    const { participants, messages } = req.body;
    const formattedMessages = messages.map(m => ({ ...m, type: 'direct' as 'direct' | 'global' }));

    try {
      const savedChat = await saveChat({ participants, messages: formattedMessages });

      if ('error' in savedChat) {
        throw new Error(savedChat.error);
      }

      // Enrich the newly created chat with message details
      const populatedChat = await populateDocument(savedChat._id.toString(), 'chat');

      if ('error' in populatedChat) {
        throw new Error(populatedChat.error);
      }

      socket.emit('chatUpdate', { chat: populatedChat as PopulatedDatabaseChat, type: 'created' });
      res.json(populatedChat);
    } catch (err: unknown) {
      res.status(500).send(`Error creating a chat: ${(err as Error).message}`);
    }
  };

  /**
   * Adds a new message to an existing chat.
   * @param req The request object containing the message data.
   * @param res The response object to send the result.
   * @returns {Promise<void>} A promise that resolves when the message is added.
   * @throws {Error} Throws an error if the message addition fails.
   */
  const addMessageToChatRoute = async (
    req: AddMessageRequestToChat,
    res: Response,
  ): Promise<void> => {
    if (!req.body || !isAddMessageRequestValid(req)) {
      res.status(400).send('Missing chatId, msg, or msgFrom');
      return;
    }

    const { chatId } = req.params;
    const { msg, msgFrom, msgDateTime, question, answer, reactions, read } = req.body;

    try {
      // Create a new message in the DB
      const newMessage = await saveMessage({
        msg,
        msgFrom,
        msgDateTime,
        type: 'direct',
        question,
        answer,
        reactions,
        read,
      });

      if ('error' in newMessage) {
        throw new Error(newMessage.error);
      }

      // Associate the message with the chat
      const updatedChat = await addMessageToChat(chatId, newMessage._id.toString());

      if ('error' in updatedChat) {
        throw new Error(updatedChat.error);
      }

      // Enrich the updated chat for the response
      const populatedChat = await populateDocument(updatedChat._id.toString(), 'chat');

      socket
        .to(chatId)
        .emit('chatUpdate', { chat: populatedChat as PopulatedDatabaseChat, type: 'newMessage' });
      res.json({
        ...populatedChat,
        answer: undefined,
        question: undefined,
      });
    } catch (err: unknown) {
      res.status(500).send(`Error adding a message to chat: ${(err as Error).message}`);
    }
  };

  /**
   * Adds a new message to an existing chat.
   * @param req The request object containing the message data.
   * @param res The response object to send the result.
   * @returns {Promise<void>} A promise that resolves when the message is added.
   * @throws {Error} Throws an error if the message addition fails.
   */
  const updateMessagesInChatRoute = async (req: MessagesToUpdate, res: Response): Promise<void> => {
    if (!req.body || !isMessagesToUpdateValid(req)) {
      res.status(400).send('Missing chatId,or msg id');
      return;
    }

    const { chatId } = req.params;
    const { messages } = req.body;

    try {
      // Create a new message in the DB
      await updateMessagesInChat(messages);
      // Enrich the updated chat for the response
      const populatedChat = await populateDocument(chatId.toString(), 'chat');

      socket.to(chatId).emit('chatUpdate', {
        chat: populatedChat as PopulatedDatabaseChat,
        type: 'updateMessages',
      });
      res.json({
        ...populatedChat,
        answer: undefined,
        question: undefined,
      });
    } catch (err: unknown) {
      res.status(500).send(`Error updating messages in chat: ${(err as Error).message}`);
    }
  };

  /**
   * updates an existing message to an existing chat.
   * @param req The request object containing the message data.
   * @param res The response object to send the result.
   * @returns {Promise<void>} A promise that resolves when the message is added.
   * @throws {Error} Throws an error if the message addition fails.
   */
  const updateMessageInChatRoute = async (
    req: UpdateMessageRequestToChat,
    res: Response,
  ): Promise<void> => {
    if (!req.body || !isUpdateMessageRequestValid(req)) {
      res.status(400).send('Missing chatId, messageId');
      return;
    }

    const { chatId } = req.params;
    const { read, reactions, seenByUser, messageId } = req.body;
    try {
      // Associate the message with the chat
      const updatedChat = await updateMessageInChat(chatId, messageId.toString(), {
        read,
        reactions,
        seenBy: seenByUser,
      });

      if ('error' in updatedChat) {
        throw new Error(updatedChat.error);
      }

      // Enrich the updated chat for the response
      const populatedChat = await populateDocument(updatedChat._id.toString(), 'chat');

      socket.to(chatId).emit('chatUpdate', {
        chat: populatedChat as PopulatedDatabaseChat,
        type: 'updateMessages',
      });
      res.json(populatedChat);
    } catch (err: unknown) {
      res.status(500).send(`Error updating a message in chat: ${(err as Error).message}`);
    }
  };

  /**
   * Retrieves a chat by its ID, optionally populating participants and messages.
   * @param req The request object containing the chat ID.
   * @param res The response object to send the result.
   * @returns {Promise<void>} A promise that resolves when the chat is retrieved.
   * @throws {Error} Throws an error if the chat retrieval fails.
   */
  const getChatRoute = async (req: ChatIdRequest, res: Response): Promise<void> => {
    const { chatId } = req.params;

    try {
      const foundChat = await getChat(chatId);
      if ('error' in foundChat) {
        throw new Error(foundChat.error);
      }
      const populatedChat = await populateDocument(foundChat._id.toString(), 'chat');

      if ('error' in populatedChat) {
        throw new Error(populatedChat.error);
      }

      res.json(populatedChat);
    } catch (err: unknown) {
      res.status(500).send(`Error retrieving chat: ${(err as Error).message}`);
    }
  };

  /**
   * Retrieves chats for a user based on their username.
   * @param req The request object containing the username parameter in `req.params`.
   * @param res The response object to send the result, either the populated chats or an error message.
   * @returns {Promise<void>} A promise that resolves when the chats are successfully retrieved and populated.
   */
  const getChatsByUserRoute = async (
    req: GetChatByParticipantsRequest,
    res: Response,
  ): Promise<void> => {
    const { username } = req.params;

    try {
      const chats = await getChatsByParticipants([username]);

      const populatedChats = await Promise.all(
        chats.map(chat => populateDocument(chat._id.toString(), 'chat')),
      );

      if (populatedChats.some(chat => 'error' in chat)) {
        throw new Error('Failed populating all retrieved chats');
      }

      res.json(populatedChats);
    } catch (err: unknown) {
      res.status(500).send(`Error retrieving chat: ${(err as Error).message}`);
    }
  };

  /**
   * Adds a participant to an existing chat.
   * @param req The request object containing the participant data.
   * @param res The response object to send the result.
   * @returns {Promise<void>} A promise that resolves when the participant is added.
   * @throws {Error} Throws an error if the participant addition fails.
   */
  const addParticipantToChatRoute = async (
    req: AddParticipantRequest,
    res: Response,
  ): Promise<void> => {
    if (!req.body || !isUpdateParticipantRequestValid(req)) {
      res.status(400).send('Missing chatId or userId');
      return;
    }

    const { chatId } = req.params;
    const { username: userId } = req.body;

    try {
      const updatedChat = await addParticipantToChat(chatId, userId);

      if ('error' in updatedChat) {
        throw new Error(updatedChat.error);
      }

      const populatedChat = await populateDocument(updatedChat._id.toString(), 'chat');

      if ('error' in populatedChat) {
        throw new Error(populatedChat.error);
      }
      socket.emit('chatUpdate', {
        chat: populatedChat as PopulatedDatabaseChat,
        type: 'newParticipant',
      });
      res.json(updatedChat);
    } catch (err: unknown) {
      res.status(500).send(`Error adding participant to chat: ${(err as Error).message}`);
    }
  };

  socket.on('connection', conn => {
    conn.on('joinChat', (chatID: string) => {
      conn.join(chatID);
    });

    conn.on('leaveChat', (chatID: string | undefined) => {
      if (chatID) {
        conn.leave(chatID);
      }
    });
  });

  /**
   * Adds a participant to an existing chat.
   * @param req The request object containing the participant data.
   * @param res The response object to send the result.
   * @returns {Promise<void>} A promise that resolves when the participant is added.
   * @throws {Error} Throws an error if the participant addition fails.
   */
  const removeParticipantToChatRoute = async (
    req: AddParticipantRequest,
    res: Response,
  ): Promise<void> => {
    if (!req.body || !isUpdateParticipantRequestValid(req)) {
      res.status(400).send('Missing chatId or userId');
      return;
    }

    const { chatId } = req.params;
    const { username: userId } = req.body;

    try {
      const updatedChat = await removeParticipantInChat(chatId, userId);

      if ('error' in updatedChat) {
        throw new Error(updatedChat.error);
      }

      const populatedChat = await populateDocument(updatedChat._id.toString(), 'chat');

      if ('error' in populatedChat) {
        throw new Error(populatedChat.error);
      }

      socket.emit('chatUpdate', {
        chat: populatedChat as PopulatedDatabaseChat,
        type: 'removeParticipant',
      });
      res.json(updatedChat);
    } catch (err: unknown) {
      res.status(500).send(`Error removing participant to chat: ${(err as Error).message}`);
    }
  };

  /**
   * Adds an interest to an existing chat.
   * @param req The request object containing the interest data.
   * @param res The response object to send the result.
   * @returns {Promise<void>} A promise that resolves when the interest is updated.
   * @throws {Error} Throws an error if the message addition fails.
   */
  const addInterestToChatRoute = async (
    req: AddInterestToChatRequest,
    res: Response,
  ): Promise<void> => {
    if (!req.body || !isAddInterestRequestValid(req)) {
      res.status(400).send('Missing chatId, or interest title');
      return;
    }

    const { chatId } = req.params;
    const { title } = req.body;

    try {
      // Try retrieving interest in DB
      const existingInterest = await getInterestByTitle(title);

      if ('error' in existingInterest) {
        if (existingInterest.error.includes('Interest not found')) {
          res.status(404).send('Interest not found.');
          return;
        }
        throw new Error(existingInterest.error);
      }

      // Associate the existing interest with the chat
      const updatedChat = await addInterestToChat(
        chatId,
        (existingInterest as DatabaseInterest)._id.toString(),
      );

      if ('error' in updatedChat) {
        throw new Error(updatedChat.error);
      }

      // Enrich the updated chat for the response
      const populatedChat = await populateDocument(updatedChat._id.toString(), 'chat');

      if ('error' in populatedChat) {
        throw new Error(populatedChat.error);
      }

      // TODO: socket?

      res.json(populatedChat);
    } catch (err: unknown) {
      res.status(500).send(`Error updating interest for chat: ${(err as Error).message}`);
    }
  };

  // Register the routes
  router.post('/createChat', createChatRoute);
  router.post('/:chatId/addMessage', addMessageToChatRoute);
  router.post('/:chatId/updateMessage', updateMessageInChatRoute);
  router.post('/:chatId/updateMessages', updateMessagesInChatRoute);
  router.get('/:chatId', getChatRoute);
  router.post('/:chatId/addParticipant', addParticipantToChatRoute);
  router.post('/:chatId/removeParticipants', removeParticipantToChatRoute);
  router.get('/getChatsByUser/:username', getChatsByUserRoute);
  router.patch('/:chatId/addInterest', addInterestToChatRoute);

  return router;
};

export default chatController;
