import { ObjectId } from 'mongodb';
import ChatModel from '../models/chat.model';
import UserModel from '../models/users.model';

import {
  Chat,
  ChatResponse,
  DatabaseChat,
  MessageResponse,
  DatabaseUser,
  DatabaseMessage,
  Message,
} from '../types/types';
import { saveMessage } from './message.service';
import AnswerModel from '../models/answers.model';
import CommentModel from '../models/comments.model';
import MessageModel from '../models/messages.model';
import QuestionModel from '../models/questions.model';

/**
 * Saves a new chat, storing any messages provided as part of the argument.
 * @param chatPayload - The chat object containing full message data.
 * @returns {Promise<ChatResponse>} - The saved chat or an error message.
 */
export const saveChat = async (chatPayload: Chat): Promise<ChatResponse> => {
  try {
    // Save the messages provided in the arugment to the database
    const messageIds: ObjectId[] = await Promise.all(
      chatPayload.messages.map(async msg => {
        const savedMessage: MessageResponse = await saveMessage(msg);

        if ('error' in savedMessage) {
          throw new Error(savedMessage.error);
        }

        return savedMessage._id;
      }),
    );

    // Create the chat using participant IDs and saved message IDs
    return await ChatModel.create({
      participants: chatPayload.participants,
      messages: messageIds,
    });
  } catch (error) {
    return { error: `Error saving chat: ${error}` };
  }
};

/**
 * Adds a message ID to a chat.
 * @param chatId - The ID of the chat to update.
 * @param messageId - The ID of the message to add.
 * @returns {Promise<ChatResponse>} - The updated chat or an error message.
 */
export const addMessageToChat = async (
  chatId: string,
  messageId: string,
): Promise<ChatResponse> => {
  try {
    const updatedChat: DatabaseChat | null = await ChatModel.findByIdAndUpdate(
      chatId,
      { $addToSet: { messages: messageId } },
      { new: true },
    );

    if (!updatedChat) {
      throw new Error('Chat not found');
    }

    return updatedChat;
  } catch (error) {
    return { error: `Error adding message to chat: ${error}` };
  }
};

/**
 * Adds a message ID to a chat.
 * @param chatId - The ID of the chat to update.
 * @param messageId - The ID of the message to add.
 * @param {Partial<Message>} updates - An object containing the fields to update and their new values.
 * @returns {Promise<ChatResponse>} - The updated chat or an error message.
 */
export const updateMessagesInChat = async (updates: Partial<DatabaseMessage>[]): Promise<void> => {
  try {
    const messageIds: ObjectId[] = await Promise.all(
      updates.map(async msg => {
        const savedMessage: DatabaseMessage | null = await MessageModel.findOneAndUpdate(
          { _id: msg._id },
          { $set: msg },
          { new: true },
        );
        if (savedMessage === null) {
          throw new Error(`error updating msg with id ${msg._id}`);
        }

        return savedMessage._id;
      }),
    );
    if (!messageIds) {
      throw Error('Error updating message');
    }
  } catch (error) {
    throw Error(`Error updating message in chat: ${error}`);
  }
};

/**
 * Adds a message ID to a chat.
 * @param chatId - The ID of the chat to update.
 * @param messageId - The ID of the message to add.
 * @param {Partial<Message>} updates - An object containing the fields to update and their new values.
 * @returns {Promise<void>} - The updated chat or an error message.
 */
export const updateMessageInChat = async (
  chatId: string,
  messageId: string,
  updates: Partial<Message>,
): Promise<ChatResponse> => {
  try {
    const updatedMessage: DatabaseMessage | null = await MessageModel.findOneAndUpdate(
      { _id: messageId },
      { $push: { reactions: updates.reactions } },
      { new: true },
    );
    if (!updatedMessage) {
      return { error: 'Error updating message' };
    }
    const updatedChat: DatabaseChat | null = await ChatModel.findOneAndUpdate(
      {
        _id: chatId, // Find the chat by chatId
        messages: messageId, // Find the specific message by its messageId inside the messages array
      },
      {
        $set: {
          'messages.$': updatedMessage, // Use the positional operator `$` to replace the matching message
        },
      },
      { new: true }, // Return the updated chat document
    );

    if (!updatedChat) {
      return { error: 'Chat not found' }; // Return error object instead of throwing
    }

    return updatedChat;
  } catch (error) {
    return { error: `Error updating message in chat` };
  }
};

/**
 * Retrieves a chat document by its ID.
 * @param chatId - The ID of the chat to retrieve.
 * @returns {Promise<ChatResponse>} - The chat or an error message.
 */
export const getChat = async (chatId: string): Promise<ChatResponse> => {
  try {
    const chat: DatabaseChat | null = await ChatModel.findById(chatId).populate([
      {
        path: 'messages',
        model: MessageModel,
        populate: [
          { path: 'question', model: QuestionModel },
          {
            path: 'answer',
            model: AnswerModel,
            populate: { path: 'comments', model: CommentModel },
          },
        ],
      },
    ]);

    if (!chat) {
      throw new Error('Chat not found');
    }

    return chat;
  } catch (error) {
    return {
      error: `Error retrieving chat: ${error instanceof Error ? error.message : 'Unknown error'}`,
    };
  }
};

/**
 * Adds a message ID to a chat.
 * @param chatId - The ID of the chat to update.
 * @param username - The ID of the user to remove.
 * @returns {Promise<ChatResponse>} - The updated chat or an error message.
 */
export const removeParticipantInChat = async (
  chatId: string,
  username: string,
): Promise<ChatResponse> => {
  try {
    const chat: DatabaseChat | null = await ChatModel.findById(chatId);

    if (!chat) {
      throw new Error('Chat not found');
    }

    // Check if the user is in the participants list
    if (!chat.participants.includes(username)) {
      return { error: 'User is not a participant in this chat' };
    }

    const updatedChat: DatabaseChat | null = await ChatModel.findByIdAndUpdate(
      chatId,
      { $pull: { participants: username } },
      { new: true },
    ).populate([
      {
        path: 'messages',
        model: MessageModel,
        populate: [
          { path: 'question', model: QuestionModel },
          {
            path: 'answer',
            model: AnswerModel,
            populate: { path: 'comments', model: CommentModel },
          },
        ],
      },
    ]);

    if (!updatedChat) {
      return { error: 'Chat not found' };
    }

    return updatedChat;
  } catch (error) {
    return { error: `Chat not found or user is not a participant` };
  }
};

/**
 * Retrieves chats that include all the provided participants.
 * @param p - An array of participant usernames or IDs.
 * @returns {Promise<DatabaseChat[]>} - An array of matching chats or an empty array.
 */
export const getChatsByParticipants = async (p: string[]): Promise<DatabaseChat[]> => {
  try {
    const chats = await ChatModel.find({ participants: { $all: p } }).lean();

    if (!chats) {
      throw new Error('Chat not found with the provided participants');
    }

    return chats;
  } catch {
    return [];
  }
};

/**
 * Adds a participant to an existing chat.
 * @param chatId - The ID of the chat to update.
 * @param userId - The user ID to add to the chat.
 * @returns {Promise<ChatResponse>} - The updated chat or an error message.
 */
export const addParticipantToChat = async (
  chatId: string,
  userId: string,
): Promise<ChatResponse> => {
  try {
    // Validate if user exists
    const userExists: DatabaseUser | null = await UserModel.findById(userId);
    if (!userExists) {
      throw new Error('User does not exist.');
    }

    // Add participant if not already in the chat
    const updatedChat: DatabaseChat | null = await ChatModel.findOneAndUpdate(
      { _id: chatId, participants: { $ne: userExists.username } },
      { $push: { participants: userExists.username } },
      { new: true }, // Return the updated document
    ).populate([
      {
        path: 'messages',
        model: MessageModel,
        populate: [
          { path: 'question', model: QuestionModel },
          {
            path: 'answer',
            model: AnswerModel,
            populate: { path: 'comments', model: CommentModel },
          },
        ],
      },
    ]);

    if (!updatedChat) {
      throw new Error('Chat not found or user already a participant.');
    }

    return updatedChat;
  } catch (error) {
    return { error: `Error adding participant to chat: ${(error as Error).message}` };
  }
};

/**
 * Adds an interest ID to a chat.
 * @param chatId - The ID of the chat to update.
 * @param interestId - The ID of the interest to update.
 * @returns {Promise<ChatResponse>} - The updated chat or an error message.
 */
export const addInterestToChat = async (
  chatId: string,
  interestId: string,
): Promise<ChatResponse> => {
  try {
    const updatedChat = await ChatModel.findByIdAndUpdate(
      chatId,
      { $set: { interest: interestId } },
      { new: true },
    );

    if (!updatedChat) {
      throw new Error('Chat not found');
    }

    return updatedChat;
  } catch (error) {
    return { error: `Error updating interest to chat: ${error}` };
  }
};
