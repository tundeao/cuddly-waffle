import InterestModel from '../models/interest.model';
import { Interest, InterestResponse, DatabaseInterest } from '../types/types';

/**
 * Saves a new chat, storing any messages provided as part of the argument.
 * @param interest - The interest object.
 * @returns {Promise<InterestResponse>} - The saved interest or an error message.
 */
export const saveInterest = async (interest: Interest): Promise<InterestResponse> => {
  try {
    const result: DatabaseInterest = await InterestModel.create(interest);

    return result;
  } catch (error) {
    return { error: `Error occurred when saving interest: ${error}` };
  }
};

/**
 * Retrieves an interest document by its title.
 * @param title - The title of the interest to retrieve.
 * @returns {Promise<InterestResponse>} - The interest or an error message.
 */
export const getInterestByTitle = async (title: string): Promise<InterestResponse> => {
  try {
    const interest: DatabaseInterest | null = await InterestModel.findOne({ title });

    if (!interest) {
      throw new Error('Interest not found');
    }

    return interest;
  } catch (error) {
    return { error: `Error retrieving interest: ${error}` };
  }
};

/**
 * Retrieves all interest documents.
 * @returns {Promise<DatabaseInterest[]>} - An array of interest or an empty array if error occurs.
 */
export const getInterests = async (): Promise<DatabaseInterest[]> => {
  try {
    const interest: DatabaseInterest[] = await InterestModel.find();

    return interest;
  } catch (error) {
    return [];
  }
};
