import mongoose from 'mongoose';
import InterestModel from '../../models/interest.model';
import { getInterestByTitle, getInterests, saveInterest } from '../../services/interest.service';
import { DatabaseInterest, Interest } from '../../types/types';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const mockingoose = require('mockingoose');

describe('Interest service', () => {
  beforeEach(() => {
    mockingoose.resetAll();
    jest.clearAllMocks();
  });

  describe('saveInterest', () => {
    const mockInterest: Interest = {
      title: 'mocked interest',
      description: 'mocked description',
      tags: ['tag1', 'tag2'],
    };

    it('should successfully save an interest and verify its body (ignore exact IDs)', async () => {
      mockingoose(InterestModel).toReturn(
        {
          _id: new mongoose.Types.ObjectId(),
          title: 'mocked interest',
          description: 'mocked description',
          tags: ['tag1', 'tag2'],
        },
        'create',
      );

      const result = (await saveInterest(mockInterest)) as DatabaseInterest;

      if ('error' in result) {
        throw new Error(`Expected a Interest, got error: ${result.error}`);
      }

      expect(result).toHaveProperty('_id');
      expect(result.description).toEqual('mocked description');
      expect(result.title).toEqual('mocked interest');
      expect(result.tags).toBeDefined();
      expect(result.tags?.length).toEqual(2);
    });
    it('should throw an error if db throw error', async () => {
      jest
        .spyOn(InterestModel, 'create')
        .mockRejectedValueOnce(() => new Error('Error saving document'));

      const saveError = await saveInterest(mockInterest);

      expect('error' in saveError).toBe(true);
    });
  });

  describe('getInterestByTitle', () => {
    it('should retrieve a interest by title', async () => {
      const mockFoundInterest: DatabaseInterest = {
        _id: new mongoose.Types.ObjectId(),
        title: 'mocked interest',
        description: 'mocked description',
        tags: ['tag1', 'tag2'],
      };
      mockingoose(InterestModel).toReturn(mockFoundInterest, 'findOne'); // or 'findById' => 'findOne'
      const result = (await getInterestByTitle('mocked interest')) as DatabaseInterest;
      if ('error' in result) {
        throw new Error('Expected a chat, got an error');
      }
      expect(result._id).toEqual(mockFoundInterest._id);
    });
    it('should return an error if the chat is not found', async () => {
      mockingoose(InterestModel).toReturn(null, 'findOne');
      const result = await getInterestByTitle('anyInterestId');
      expect('error' in result).toBe(true);
      if ('error' in result) {
        expect(result.error).toContain('Interest not found');
      }
    });
    it('should return an error if DB fails', async () => {
      jest.spyOn(InterestModel, 'findOne').mockRejectedValueOnce(new Error('DB Error'));
      const result = await getInterestByTitle('dbFailInterestId');
      expect('error' in result).toBe(true);
      if ('error' in result) {
        expect(result.error).toContain('Error retrieving interest:');
      }
    });
  });

  describe('getInterests', () => {
    const interest1: Interest = {
      title: 'mocked interest',
      description: 'mocked description',
      tags: ['tag1', 'tag2'],
    };
    const interest2: Interest = {
      title: 'mocked interest',
      description: 'mocked description',
      tags: ['tag1', 'tag2'],
    };
    it('should return all interests', async () => {
      mockingoose(InterestModel).toReturn([interest1, interest2], 'find');

      const messages = await getInterests();

      expect(messages).toMatchObject([interest1, interest2]);
    });

    it('should return an empty array if error when retrieving interests', async () => {
      jest
        .spyOn(InterestModel, 'find')
        .mockRejectedValueOnce(() => new Error('Error retrieving documents'));

      const messages = await getInterests();

      expect(messages).toEqual([]);
    });
  });
});
