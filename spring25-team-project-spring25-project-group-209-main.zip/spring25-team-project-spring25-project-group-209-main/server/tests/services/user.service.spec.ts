import mongoose from 'mongoose';
import UserModel from '../../models/users.model';
import {
  deleteUserByUsername,
  getUserByUsername,
  getUsersByInterest,
  getUsersList,
  loginUser,
  saveUser,
  updateUser,
  getUserBadgeByDescription,
  updateUserInterest,
} from '../../services/user.service';
import { Badge, SafeDatabaseUser, User, UserCredentials } from '../../types/types';
import { user, safeUser } from '../mockData.models';

// eslint-disable-next-line @typescript-eslint/no-var-requires
const mockingoose = require('mockingoose');

describe('User model', () => {
  beforeEach(() => {
    mockingoose.resetAll();
  });

  describe('saveUser', () => {
    beforeEach(() => {
      mockingoose.resetAll();
    });

    it('should return the saved user', async () => {
      mockingoose(UserModel).toReturn(user, 'create');

      const savedUser = (await saveUser(user)) as SafeDatabaseUser;

      expect(savedUser._id).toBeDefined();
      expect(savedUser.username).toEqual(user.username);
      expect(savedUser.dateJoined).toEqual(user.dateJoined);
    });

    it('should throw an error if error when saving to database', async () => {
      jest
        .spyOn(UserModel, 'create')
        .mockRejectedValueOnce(() => new Error('Error saving document'));

      const saveError = await saveUser(user);

      expect('error' in saveError).toBe(true);
    });
  });
});

describe('getUserByUsername', () => {
  beforeEach(() => {
    mockingoose.resetAll();
  });

  it('should return the matching user', async () => {
    mockingoose(UserModel).toReturn(safeUser, 'findOne');

    const retrievedUser = (await getUserByUsername(user.username)) as SafeDatabaseUser;

    expect(retrievedUser.username).toEqual(user.username);
    expect(retrievedUser.dateJoined).toEqual(user.dateJoined);
  });

  it('should throw an error if the user is not found', async () => {
    mockingoose(UserModel).toReturn(null, 'findOne');

    const getUserError = await getUserByUsername(user.username);

    expect('error' in getUserError).toBe(true);
  });

  it('should throw an error if there is an error while searching the database', async () => {
    mockingoose(UserModel).toReturn(new Error('Error finding document'), 'findOne');

    const getUserError = await getUserByUsername(user.username);

    expect('error' in getUserError).toBe(true);
  });
});

describe('getUsersList', () => {
  beforeEach(() => {
    mockingoose.resetAll();
  });

  it('should return the users', async () => {
    mockingoose(UserModel).toReturn([safeUser], 'find');

    const retrievedUsers = (await getUsersList()) as SafeDatabaseUser[];

    expect(retrievedUsers[0].username).toEqual(safeUser.username);
    expect(retrievedUsers[0].dateJoined).toEqual(safeUser.dateJoined);
  });

  it('should throw an error if the users cannot be found', async () => {
    mockingoose(UserModel).toReturn(null, 'find');

    const getUsersError = await getUsersList();

    expect('error' in getUsersError).toBe(true);
  });

  it('should throw an error if there is an error while searching the database', async () => {
    mockingoose(UserModel).toReturn(new Error('Error finding document'), 'find');

    const getUsersError = await getUsersList();

    expect('error' in getUsersError).toBe(true);
  });
});

describe('loginUser', () => {
  beforeEach(() => {
    mockingoose.resetAll();
  });

  it('should return the user if authentication succeeds', async () => {
    mockingoose(UserModel).toReturn(safeUser, 'findOne');

    const credentials: UserCredentials = {
      username: user.username,
      password: user.password,
    };

    const loggedInUser = (await loginUser(credentials)) as SafeDatabaseUser;

    expect(loggedInUser.username).toEqual(user.username);
    expect(loggedInUser.dateJoined).toEqual(user.dateJoined);
  });

  it('should return the user if the password fails', async () => {
    mockingoose(UserModel).toReturn(null, 'findOne');

    const credentials: UserCredentials = {
      username: user.username,
      password: 'wrongPassword',
    };

    const loginError = await loginUser(credentials);

    expect('error' in loginError).toBe(true);
  });

  it('should return the user is not found', async () => {
    mockingoose(UserModel).toReturn(null, 'findOne');

    const credentials: UserCredentials = {
      username: 'wrongUsername',
      password: user.password,
    };

    const loginError = await loginUser(credentials);

    expect('error' in loginError).toBe(true);
  });
});

describe('deleteUserByUsername', () => {
  beforeEach(() => {
    mockingoose.resetAll();
  });

  it('should return the deleted user when deleted succesfully', async () => {
    mockingoose(UserModel).toReturn(safeUser, 'findOneAndDelete');

    const deletedUser = (await deleteUserByUsername(user.username)) as SafeDatabaseUser;

    expect(deletedUser.username).toEqual(user.username);
    expect(deletedUser.dateJoined).toEqual(user.dateJoined);
  });

  it('should throw an error if the username is not found', async () => {
    mockingoose(UserModel).toReturn(null, 'findOneAndDelete');

    const deletedError = await deleteUserByUsername(user.username);

    expect('error' in deletedError).toBe(true);
  });

  it('should throw an error if a database error while deleting', async () => {
    mockingoose(UserModel).toReturn(new Error('Error deleting object'), 'findOneAndDelete');

    const deletedError = await deleteUserByUsername(user.username);

    expect('error' in deletedError).toBe(true);
  });
});

describe('updateUser', () => {
  const updatedUser: User = {
    ...user,
    password: 'newPassword',
  };

  const safeUpdatedUser: SafeDatabaseUser = {
    _id: new mongoose.Types.ObjectId(),
    username: user.username,
    dateJoined: user.dateJoined,
  };

  const updates: Partial<User> = {
    password: 'newPassword',
  };

  beforeEach(() => {
    mockingoose.resetAll();
  });

  it('should return the updated user when updated succesfully', async () => {
    mockingoose(UserModel).toReturn(safeUpdatedUser, 'findOneAndUpdate');

    const result = (await updateUser(user.username, updates)) as SafeDatabaseUser;

    expect(result.username).toEqual(user.username);
    expect(result.username).toEqual(updatedUser.username);
    expect(result.dateJoined).toEqual(user.dateJoined);
    expect(result.dateJoined).toEqual(updatedUser.dateJoined);
  });

  it('should throw an error if the username is not found', async () => {
    mockingoose(UserModel).toReturn(null, 'findOneAndUpdate');

    const updatedError = await updateUser(user.username, updates);

    expect('error' in updatedError).toBe(true);
  });

  it('should throw an error if a database error while deleting', async () => {
    mockingoose(UserModel).toReturn(new Error('Error updating object'), 'findOneAndUpdate');

    const updatedError = await updateUser(user.username, updates);

    expect('error' in updatedError).toBe(true);
  });

  it('should update the biography if the user is found', async () => {
    const newBio = 'This is a new biography';
    // Make a new partial updates object just for biography
    const biographyUpdates: Partial<User> = { biography: newBio };

    // Mock the DB to return a safe user (i.e., no password in results)
    mockingoose(UserModel).toReturn({ ...safeUpdatedUser, biography: newBio }, 'findOneAndUpdate');

    const result = await updateUser(user.username, biographyUpdates);

    // Check that the result is a SafeUser and the biography got updated
    if ('username' in result) {
      expect(result.biography).toEqual(newBio);
    } else {
      throw new Error('Expected a safe user, got an error object.');
    }
  });

  it('should return an error if biography update fails because user not found', async () => {
    // Simulate user not found
    mockingoose(UserModel).toReturn(null, 'findOneAndUpdate');

    const newBio = 'No user found test';
    const biographyUpdates: Partial<User> = { biography: newBio };
    const updatedError = await updateUser(user.username, biographyUpdates);

    expect('error' in updatedError).toBe(true);
  });

  describe('getUsersByInterest', () => {
    beforeEach(() => {
      mockingoose.resetAll();
    });
    const interestId = new mongoose.Types.ObjectId();
    const safeUserWithInterest = {
      ...safeUser,
      interest: {
        _id: interestId,
        title: 'mocked interest',
        description: 'mocked description',
        tags: ['tag1', 'tag2'],
      },
    };

    it('should return the users with matching interests', async () => {
      mockingoose(UserModel).toReturn([safeUserWithInterest], 'find');

      const retrievedUsers = (await getUsersByInterest(
        interestId.toString(),
      )) as SafeDatabaseUser[];

      expect(retrievedUsers[0].username).toEqual(safeUser.username);
      expect(retrievedUsers[0].dateJoined).toEqual(safeUser.dateJoined);
    });

    it('should throw an error if the users cannot be found', async () => {
      mockingoose(UserModel).toReturn(null, 'find');

      const getUsersError = await getUsersByInterest(interestId.toString());

      expect('error' in getUsersError).toBe(true);
    });

    it('should throw an error if there is an error while searching the database', async () => {
      mockingoose(UserModel).toReturn(new Error('Error finding document'), 'find');

      const getUsersError = await getUsersByInterest(interestId.toString());

      expect('error' in getUsersError).toBe(true);
    });
  });

  describe('updateUserInterest', () => {
    const interestId = new mongoose.Types.ObjectId();
    const updatedUserWithInterest: User = {
      ...user,
      password: 'newPassword',
      interests: [interestId],
    };

    const updatedUserWithoutInterest: User = {
      ...user,
      password: 'newPassword',
      interests: [],
    };

    const safeUpdatedUserWithIntereset: SafeDatabaseUser = {
      _id: new mongoose.Types.ObjectId(),
      username: user.username,
      dateJoined: user.dateJoined,
      interests: [interestId],
    };

    const safeUpdatedUserWithoutInterest: SafeDatabaseUser = {
      _id: interestId,
      username: user.username,
      dateJoined: user.dateJoined,
      interests: [],
    };

    beforeEach(() => {
      mockingoose.resetAll();
    });

    it('should return the updated user with a new interest when user joins and updates succesfully', async () => {
      mockingoose(UserModel).toReturn(safeUpdatedUserWithIntereset, 'findOneAndUpdate');

      const result = (await updateUserInterest(
        user.username,
        interestId.toString(),
        'join',
      )) as SafeDatabaseUser;

      expect(result.username).toEqual(updatedUserWithInterest.username);
      expect(result.dateJoined).toEqual(updatedUserWithInterest.dateJoined);
      expect(result.interests?.length).toEqual(1);
    });

    it('should return the updated user with a deleted interest when user leaves and updates succesfully', async () => {
      mockingoose(UserModel).toReturn(safeUpdatedUserWithoutInterest, 'findOneAndUpdate');

      const result = (await updateUserInterest(
        user.username,
        interestId.toString(),
        'leave',
      )) as SafeDatabaseUser;

      expect(result.username).toEqual(updatedUserWithoutInterest.username);
      expect(result.dateJoined).toEqual(updatedUserWithoutInterest.dateJoined);
      expect(result.interests?.length).toEqual(0);
    });

    it('should return the updated user with deleted user joins and updates succesfully', async () => {
      mockingoose(UserModel).toReturn(safeUpdatedUserWithIntereset, 'findOneAndUpdate');

      const result = (await updateUserInterest(
        user.username,
        interestId.toString(),
        'join',
      )) as SafeDatabaseUser;

      expect(result.username).toEqual(updatedUserWithInterest.username);
      expect(result.dateJoined).toEqual(updatedUserWithInterest.dateJoined);
      expect(result.dateJoined).toEqual(updatedUserWithInterest.dateJoined);
    });

    it('should throw an error if the username is not found', async () => {
      mockingoose(UserModel).toReturn(null, 'findOneAndUpdate');

      const updatedError = await updateUserInterest(user.username, interestId.toString(), 'join');

      expect('error' in updatedError).toBe(true);
    });

    it('should throw an error if a database error while deleting', async () => {
      mockingoose(UserModel).toReturn(new Error('Error updating object'), 'findOneAndUpdate');

      const updatedError = await updateUserInterest(user.username, interestId.toString(), 'join');

      expect('error' in updatedError).toBe(true);
    });
  });
});

describe('getUserBadgeByTitle', () => {
  const mockBadge: Badge = {
    title: 'First Answer',
    description: 'Answered your first question',
    type: 'answer',
    dateAwarded: new Date('2024-01-15'),
  };

  // Create a user document that will properly handle the badges array in Mongoose
  const mockUserWithBadgeDoc = {
    _id: safeUser._id,
    username: safeUser.username,
    dateJoined: safeUser.dateJoined,
    badges: [mockBadge],
    toObject() {
      return {
        _id: this._id,
        username: this.username,
        dateJoined: this.dateJoined,
        badges: this.badges,
      };
    },
  };

  const mockUserWithMultipleBadgesDoc = {
    _id: safeUser._id,
    username: safeUser.username,
    dateJoined: safeUser.dateJoined,
    badges: [
      mockBadge,
      {
        title: 'First Question',
        description: 'Asked your first question',
        type: 'question',
        dateAwarded: new Date('2024-01-10'),
      },
    ],
    toObject() {
      return {
        _id: this._id,
        username: this.username,
        dateJoined: this.dateJoined,
        badges: this.badges,
      };
    },
  };

  beforeEach(() => {
    mockingoose.resetAll();
    jest.clearAllMocks();
  });

  it('should return the badge if it exists for the user', async () => {
    // Use a more flexible typing approach
    const mockSelect = jest.fn().mockResolvedValueOnce(mockUserWithBadgeDoc);
    const mockFindOne = { select: mockSelect } as unknown as ReturnType<typeof UserModel.findOne>;

    jest.spyOn(UserModel, 'findOne').mockReturnValueOnce(mockFindOne);

    const result = await getUserBadgeByDescription(user.username, mockBadge.description);

    // Make sure the result is not an error
    expect('error' in result).toBe(false);

    if (!('error' in result)) {
      // Compare badge properties
      expect(result.title).toEqual(mockBadge.title);
      expect(result.description).toEqual(mockBadge.description);
      expect(result.type).toEqual(mockBadge.type);
    }
  });

  it('should return the correct badge from multiple badges', async () => {
    const mockSelect = jest.fn().mockResolvedValueOnce(mockUserWithMultipleBadgesDoc);
    const mockFindOne = { select: mockSelect } as unknown as ReturnType<typeof UserModel.findOne>;

    jest.spyOn(UserModel, 'findOne').mockReturnValueOnce(mockFindOne);

    const result = await getUserBadgeByDescription(user.username, mockBadge.description);

    // Make sure the result is not an error
    expect('error' in result).toBe(false);

    if (!('error' in result)) {
      // Compare badge properties
      expect(result.title).toEqual(mockBadge.title);
      expect(result.description).toEqual(mockBadge.description);
      expect(result.type).toEqual(mockBadge.type);
    }
  });

  it('should return an error if user is not found', async () => {
    const mockSelect = jest.fn().mockResolvedValueOnce(null);
    const mockFindOne = { select: mockSelect } as unknown as ReturnType<typeof UserModel.findOne>;

    jest.spyOn(UserModel, 'findOne').mockReturnValueOnce(mockFindOne);

    const result = await getUserBadgeByDescription(user.username, mockBadge.description);

    expect('error' in result).toBe(true);
    if ('error' in result) {
      expect(result.error).toContain('User not found');
    }
  });

  it('should return an error if user has an empty badges array', async () => {
    // Create a user with an empty badges array
    const userWithEmptyBadges = {
      _id: safeUser._id,
      username: safeUser.username,
      dateJoined: safeUser.dateJoined,
      badges: [], // Empty array, not null
    };

    const mockSelect = jest.fn().mockResolvedValueOnce(userWithEmptyBadges);
    const mockFindOne = { select: mockSelect } as unknown as ReturnType<typeof UserModel.findOne>;

    jest.spyOn(UserModel, 'findOne').mockReturnValueOnce(mockFindOne);

    const result = await getUserBadgeByDescription(user.username, mockBadge.description);

    expect('error' in result).toBe(true);
    if ('error' in result) {
      // With the current implementation, an empty badges array leads to
      // "Badge not found" error, not "User has no badges"
      expect(result.error).toContain('Badge not found');
    }
  });

  it('should return an error if user has no badges property', async () => {
    // Create a user with null badges (this is different from empty array)
    const userWithNullBadges = {
      _id: safeUser._id,
      username: safeUser.username,
      dateJoined: safeUser.dateJoined,
      badges: null, // Null instead of empty array
    };

    const mockSelect = jest.fn().mockResolvedValueOnce(userWithNullBadges);
    const mockFindOne = { select: mockSelect } as unknown as ReturnType<typeof UserModel.findOne>;

    jest.spyOn(UserModel, 'findOne').mockReturnValueOnce(mockFindOne);

    const result = await getUserBadgeByDescription(user.username, mockBadge.description);

    expect('error' in result).toBe(true);
    if ('error' in result) {
      // In this case, we should get "User has no badges"
      expect(result.error).toContain('User has no badges');
    }
  });

  it('should return an error if the badge is not found', async () => {
    const mockSelect = jest.fn().mockResolvedValueOnce(mockUserWithBadgeDoc);
    const mockFindOne = { select: mockSelect } as unknown as ReturnType<typeof UserModel.findOne>;

    jest.spyOn(UserModel, 'findOne').mockReturnValueOnce(mockFindOne);

    const result = await getUserBadgeByDescription(user.username, 'Nonexistent Badge');

    expect('error' in result).toBe(true);
    if ('error' in result) {
      expect(result.error).toContain('Badge not found');
    }
  });

  it('should return an error if there is a database error', async () => {
    const mockSelect = jest.fn().mockRejectedValueOnce(new Error('Database connection error'));
    const mockFindOne = { select: mockSelect } as unknown as ReturnType<typeof UserModel.findOne>;

    jest.spyOn(UserModel, 'findOne').mockReturnValueOnce(mockFindOne);

    const result = await getUserBadgeByDescription(user.username, mockBadge.description);

    expect('error' in result).toBe(true);
    if ('error' in result) {
      expect(result.error).toContain('Error occurred when finding badge');
    }
  });
});
