import mongoose from 'mongoose';
import supertest from 'supertest';
import { app } from '../../app';
import * as util from '../../services/interest.service';
import { DatabaseInterest, Interest } from '../../types/types';

const saveInterestSpy = jest.spyOn(util, 'saveInterest');
const getInterestsSpy = jest.spyOn(util, 'getInterests');

describe('POST /addInterest', () => {
  it('should add a new interest', async () => {
    const validId = new mongoose.Types.ObjectId();

    const requestInterest: Interest = {
      title: 'mocked interest',
      description: 'mocked description',
      tags: ['tag1', 'tag2'],
    };

    const interest: DatabaseInterest = {
      ...requestInterest,
      _id: validId,
    };

    saveInterestSpy.mockResolvedValue(interest);

    const response = await supertest(app).post('/interests/addInterest').send(requestInterest);

    expect(response.status).toBe(200);
    expect(response.body).toEqual({
      _id: interest._id.toString(),
      title: interest.title,
      description: interest.description,
      tags: interest.tags,
    });
  });

  it('should return bad interest body error if title is empty', async () => {
    const badInterest = {
      title: '',
      description: 'mocked description',
      tags: ['tag1', 'tag2'],
    };

    const response = await supertest(app)
      .post('/interests/addInterest')
      .send({ interestToAdd: badInterest });

    expect(response.status).toBe(400);
    expect(response.text).toBe('Invalid interest body');
  });
  it('should return bad interest body error if title is missing', async () => {
    const badInterest = {
      description: 'mocked description',
      tags: ['tag1', 'tag2'],
    };

    const response = await supertest(app).post('/interests/addInterest').send(badInterest);

    expect(response.status).toBe(400);
    expect(response.text).toBe('Invalid interest body');
  });

  it('should return bad interest body error if description is empty', async () => {
    const badInterest = {
      title: 'mocked title',
      description: '',
      tags: ['tag1', 'tag2'],
    };

    const response = await supertest(app).post('/interests/addInterest').send(badInterest);

    expect(response.status).toBe(400);
    expect(response.text).toBe('Invalid interest body');
  });

  it('should return bad interest body error if description is missing', async () => {
    const badInterest = {
      title: 'mocked title',
      tags: ['tag1', 'tag2'],
    };

    const response = await supertest(app).post('/interests/addInterest').send(badInterest);

    expect(response.status).toBe(400);
    expect(response.text).toBe('Invalid interest body');
  });

  it('should return internal server error if saveInterest fails', async () => {
    const validId = new mongoose.Types.ObjectId();
    const interest = {
      _id: validId,
      title: 'mocked title',
      description: 'mocked description',
      tags: ['tag1', 'tag2'],
    };

    saveInterestSpy.mockResolvedValue({ error: 'Error saving document' });

    const response = await supertest(app).post('/interests/addInterest').send(interest);

    expect(response.status).toBe(500);
    expect(response.text).toBe('Error when adding a interest: Error saving document');
  });
});

describe('GET /getInterests', () => {
  it('should return all interests', async () => {
    const interest1: Interest = {
      title: 'mocked title1',
      description: 'mocked description1',
      tags: ['tag1', 'tag2'],
    };

    const interest2: Interest = {
      title: 'mocked title2',
      description: 'mocked description2',
    };

    const dbInterest1: DatabaseInterest = {
      ...interest1,
      _id: new mongoose.Types.ObjectId(),
    };

    const dbInterest2: DatabaseInterest = {
      ...interest2,
      _id: new mongoose.Types.ObjectId(),
    };

    getInterestsSpy.mockResolvedValue([dbInterest1, dbInterest2]);

    const response = await supertest(app).get('/interests/getInterests');

    expect(response.status).toBe(200);
    expect(response.body).toEqual([
      {
        ...dbInterest1,
        _id: dbInterest1._id.toString(),
      },
      {
        ...dbInterest2,
        _id: dbInterest2._id.toString(),
      },
    ]);
  });
});
