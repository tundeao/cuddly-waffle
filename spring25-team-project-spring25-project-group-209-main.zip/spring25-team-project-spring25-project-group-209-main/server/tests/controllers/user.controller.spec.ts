import supertest from 'supertest';
import mongoose from 'mongoose';
import { app } from '../../app';
import * as util from '../../services/user.service';
import { Badge, SafeDatabaseUser, User } from '../../types/types';
import * as interestUtil from '../../services/interest.service';
import * as databaseUtil from '../../utils/database.util';

const mockUser: User = {
  username: 'user1',
  password: 'password',
  dateJoined: new Date('2024-12-03'),
};

const mockSafeUser: SafeDatabaseUser = {
  _id: new mongoose.Types.ObjectId(),
  username: 'user1',
  dateJoined: new Date('2024-12-03'),
};

const mockUserJSONResponse = {
  _id: mockSafeUser._id.toString(),
  username: 'user1',
  dateJoined: new Date('2024-12-03').toISOString(),
};

const saveUserSpy = jest.spyOn(util, 'saveUser');
const loginUserSpy = jest.spyOn(util, 'loginUser');
const updatedUserSpy = jest.spyOn(util, 'updateUser');
const updatedUserInterestSpy = jest.spyOn(util, 'updateUserInterest');
const getInterestByTitleSpy = jest.spyOn(interestUtil, 'getInterestByTitle');
const popDocSpy = jest.spyOn(databaseUtil, 'populateDocument');
const getUserByUsernameSpy = jest.spyOn(util, 'getUserByUsername');
const getUsersListSpy = jest.spyOn(util, 'getUsersList');
const deleteUserByUsernameSpy = jest.spyOn(util, 'deleteUserByUsername');
const getUsersByInterestSpy = jest.spyOn(util, 'getUsersByInterest');

describe('Test userController', () => {
  describe('POST /signup', () => {
    it('should create a new user given correct arguments', async () => {
      const mockReqBody = {
        username: mockUser.username,
        password: mockUser.password,
        biography: 'This is a test biography',
      };

      saveUserSpy.mockResolvedValueOnce({ ...mockSafeUser, biography: mockReqBody.biography });

      const response = await supertest(app).post('/user/signup').send(mockReqBody);

      expect(response.status).toBe(200);
      expect(response.body).toEqual({ ...mockUserJSONResponse, biography: mockReqBody.biography });
      expect(saveUserSpy).toHaveBeenCalledWith({
        ...mockReqBody,
        biography: mockReqBody.biography,
        dateJoined: expect.any(Date),
      });
    });

    it('should return 400 for request missing username', async () => {
      const mockReqBody = {
        password: mockUser.password,
      };

      const response = await supertest(app).post('/user/signup').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request with empty username', async () => {
      const mockReqBody = {
        username: '',
        password: mockUser.password,
      };

      const response = await supertest(app).post('/user/signup').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request missing password', async () => {
      const mockReqBody = {
        username: mockUser.username,
      };

      const response = await supertest(app).post('/user/signup').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request with empty password', async () => {
      const mockReqBody = {
        username: mockUser.username,
        password: '',
      };

      const response = await supertest(app).post('/user/signup').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 500 for a database error while saving', async () => {
      const mockReqBody = {
        username: mockUser.username,
        password: mockUser.password,
      };

      saveUserSpy.mockResolvedValueOnce({ error: 'Error saving user' });

      const response = await supertest(app).post('/user/signup').send(mockReqBody);

      expect(response.status).toBe(500);
    });
  });

  describe('POST /login', () => {
    it('should succesfully login for a user given correct arguments', async () => {
      const mockReqBody = {
        username: mockUser.username,
        password: mockUser.password,
      };

      loginUserSpy.mockResolvedValueOnce(mockSafeUser);

      const response = await supertest(app).post('/user/login').send(mockReqBody);

      expect(response.status).toBe(200);
      expect(response.body).toEqual(mockUserJSONResponse);
      expect(loginUserSpy).toHaveBeenCalledWith(mockReqBody);
    });

    it('should return 400 for request missing username', async () => {
      const mockReqBody = {
        password: mockUser.password,
      };

      const response = await supertest(app).post('/user/login').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request with empty username', async () => {
      const mockReqBody = {
        username: '',
        password: mockUser.password,
      };

      const response = await supertest(app).post('/user/login').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request missing password', async () => {
      const mockReqBody = {
        username: mockUser.username,
      };

      const response = await supertest(app).post('/user/login').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request with empty password', async () => {
      const mockReqBody = {
        username: mockUser.username,
        password: '',
      };

      const response = await supertest(app).post('/user/login').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 500 for a database error while saving', async () => {
      const mockReqBody = {
        username: mockUser.username,
        password: mockUser.password,
      };

      loginUserSpy.mockResolvedValueOnce({ error: 'Error authenticating user' });

      const response = await supertest(app).post('/user/login').send(mockReqBody);

      expect(response.status).toBe(500);
    });
  });

  describe('POST /resetPassword', () => {
    it('should succesfully return updated user object given correct arguments', async () => {
      const mockReqBody = {
        username: mockUser.username,
        password: 'newPassword',
      };

      updatedUserSpy.mockResolvedValueOnce(mockSafeUser);

      const response = await supertest(app).patch('/user/resetPassword').send(mockReqBody);

      expect(response.status).toBe(200);
      expect(response.body).toEqual({ ...mockUserJSONResponse });
      expect(updatedUserSpy).toHaveBeenCalledWith(mockUser.username, { password: 'newPassword' });
    });

    it('should return 400 for request missing username', async () => {
      const mockReqBody = {
        password: 'newPassword',
      };

      const response = await supertest(app).patch('/user/resetPassword').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request with empty username', async () => {
      const mockReqBody = {
        username: '',
        password: 'newPassword',
      };

      const response = await supertest(app).patch('/user/resetPassword').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request missing password', async () => {
      const mockReqBody = {
        username: mockUser.username,
      };

      const response = await supertest(app).patch('/user/resetPassword').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request with empty password', async () => {
      const mockReqBody = {
        username: mockUser.username,
        password: '',
      };

      const response = await supertest(app).patch('/user/resetPassword').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 500 for a database error while updating', async () => {
      const mockReqBody = {
        username: mockUser.username,
        password: 'newPassword',
      };

      updatedUserSpy.mockResolvedValueOnce({ error: 'Error updating user' });

      const response = await supertest(app).patch('/user/resetPassword').send(mockReqBody);

      expect(response.status).toBe(500);
    });
  });

  describe('GET /getUser', () => {
    it('should return the user given correct arguments', async () => {
      getUserByUsernameSpy.mockResolvedValueOnce(mockSafeUser);

      popDocSpy.mockResolvedValueOnce({
        ...mockSafeUser,
      });

      const response = await supertest(app).get(`/user/getUser/${mockUser.username}`);

      expect(response.status).toBe(200);
      expect(response.body).toEqual(mockUserJSONResponse);
      expect(getUserByUsernameSpy).toHaveBeenCalledWith(mockUser.username);
    });

    it('should return 500 if database error while searching username', async () => {
      getUserByUsernameSpy.mockResolvedValueOnce({ error: 'Error finding user' });

      const response = await supertest(app).get(`/user/getUser/${mockUser.username}`);

      expect(response.status).toBe(500);
    });

    it('should return 500 if populate errors', async () => {
      getUserByUsernameSpy.mockResolvedValueOnce(mockSafeUser);
      popDocSpy.mockResolvedValueOnce({ error: 'Error populating user' });

      const response = await supertest(app).get(`/user/getUser/${mockUser.username}`);

      expect(response.status).toBe(500);
    });

    it('should return 404 if username not provided', async () => {
      // Express automatically returns 404 for missing parameters when
      // defined as required in the route
      const response = await supertest(app).get('/user/getUser/');
      expect(response.status).toBe(404);
    });
  });

  describe('GET /getUsers', () => {
    it('should return the users from the database', async () => {
      getUsersListSpy.mockResolvedValueOnce([mockSafeUser]);

      const response = await supertest(app).get(`/user/getUsers`);

      expect(response.status).toBe(200);
      expect(response.body).toEqual([mockUserJSONResponse]);
      expect(getUsersListSpy).toHaveBeenCalled();
    });

    it('should return 500 if database error while finding users', async () => {
      getUsersListSpy.mockResolvedValueOnce({ error: 'Error finding users' });

      const response = await supertest(app).get(`/user/getUsers`);

      expect(response.status).toBe(500);
    });
  });

  describe('DELETE /deleteUser', () => {
    it('should return the deleted user given correct arguments', async () => {
      deleteUserByUsernameSpy.mockResolvedValueOnce(mockSafeUser);

      const response = await supertest(app).delete(`/user/deleteUser/${mockUser.username}`);

      expect(response.status).toBe(200);
      expect(response.body).toEqual(mockUserJSONResponse);
      expect(deleteUserByUsernameSpy).toHaveBeenCalledWith(mockUser.username);
    });

    it('should return 500 if database error while searching username', async () => {
      deleteUserByUsernameSpy.mockResolvedValueOnce({ error: 'Error deleting user' });

      const response = await supertest(app).delete(`/user/deleteUser/${mockUser.username}`);

      expect(response.status).toBe(500);
    });

    it('should return 404 if username not provided', async () => {
      // Express automatically returns 404 for missing parameters when
      // defined as required in the route
      const response = await supertest(app).delete('/user/deleteUser/');
      expect(response.status).toBe(404);
    });
  });

  describe('PATCH /updateBiography', () => {
    it('should successfully update biography given correct arguments', async () => {
      const mockReqBody = {
        username: mockUser.username,
        biography: 'This is my new bio',
      };

      // Mock a successful updateUser call
      updatedUserSpy.mockResolvedValueOnce(mockSafeUser);

      const response = await supertest(app).patch('/user/updateBiography').send(mockReqBody);

      expect(response.status).toBe(200);
      expect(response.body).toEqual(mockUserJSONResponse);
      // Ensure updateUser is called with the correct args
      expect(updatedUserSpy).toHaveBeenCalledWith(mockUser.username, {
        biography: 'This is my new bio',
      });
    });

    it('should return 400 for request missing username', async () => {
      const mockReqBody = {
        biography: 'some new biography',
      };

      const response = await supertest(app).patch('/user/updateBiography').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request with empty username', async () => {
      const mockReqBody = {
        username: '',
        biography: 'a new bio',
      };

      const response = await supertest(app).patch('/user/updateBiography').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request missing biography field', async () => {
      const mockReqBody = {
        username: mockUser.username,
      };

      const response = await supertest(app).patch('/user/updateBiography').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 500 if updateUser returns an error', async () => {
      const mockReqBody = {
        username: mockUser.username,
        biography: 'Attempting update biography',
      };

      // Simulate a DB error
      updatedUserSpy.mockResolvedValueOnce({ error: 'Error updating user' });

      const response = await supertest(app).patch('/user/updateBiography').send(mockReqBody);

      expect(response.status).toBe(500);
      expect(response.text).toContain(
        'Error when updating user biography: Error: Error updating user',
      );
    });
  });

  describe('PATCH /updateBadge', () => {
    it('should successfully add a badge given correct arguments', async () => {
      const mockBadge = {
        title: 'First Answer',
        description: 'Answered your first question',
        type: 'answer',
        dateAwarded: new Date(),
      };

      const mockReqBody = {
        username: mockUser.username,
        badgeTitle: mockBadge.title,
        badgeDescription: mockBadge.description,
        badgeType: mockBadge.type as 'question' | 'answer',
        action: 'add' as 'add' | 'remove',
      };

      // Mock the current user with no badges
      getUserByUsernameSpy.mockResolvedValueOnce({
        ...mockSafeUser,
        badges: [],
      });

      // Mock a successful update
      updatedUserSpy.mockResolvedValueOnce({
        ...mockSafeUser,
        badges: [mockBadge],
      });

      const response = await supertest(app).patch('/user/updateBadge').send(mockReqBody);

      expect(response.status).toBe(200);
      expect(response.body).toEqual({
        ...mockUserJSONResponse,
        badges: [
          expect.objectContaining({
            title: mockBadge.title,
            description: mockBadge.description,
            type: mockBadge.type,
          }),
        ],
      });

      // First, verify getUserByUsername was called
      expect(getUserByUsernameSpy).toHaveBeenCalledWith(mockUser.username);

      // Then, verify updateUser was called with the right parameters
      expect(updatedUserSpy).toHaveBeenCalledWith(mockUser.username, {
        badges: [
          expect.objectContaining({
            title: mockBadge.title,
            description: mockBadge.description,
            type: mockBadge.type,
          }),
        ],
      });
    });

    it('should return 400 for request missing username', async () => {
      const mockReqBody = {
        badgeTitle: 'Badge Title',
        badgeDescription: 'Badge Description',
        badgeType: 'question' as 'question' | 'answer',
        action: 'add' as 'add' | 'remove',
      };

      const response = await supertest(app).patch('/user/updateBadge').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid badge request body');
    });

    it('should return 400 for request with empty username', async () => {
      const mockReqBody = {
        username: '',
        badgeTitle: 'Badge Title',
        badgeDescription: 'Badge Description',
        badgeType: 'question' as 'question' | 'answer',
        action: 'add' as 'add' | 'remove',
      };

      const response = await supertest(app).patch('/user/updateBadge').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid badge request body');
    });

    it('should return 400 for request missing badgeTitle', async () => {
      const mockReqBody = {
        username: mockUser.username,
        badgeDescription: 'Badge Description',
        badgeType: 'question' as 'question' | 'answer',
        action: 'add' as 'add' | 'remove',
      };

      const response = await supertest(app).patch('/user/updateBadge').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid badge request body');
    });

    it('should return 400 for request with empty badgeTitle', async () => {
      const mockReqBody = {
        username: mockUser.username,
        badgeTitle: '',
        badgeDescription: 'Badge Description',
        badgeType: 'question' as 'question' | 'answer',
        action: 'add' as 'add' | 'remove',
      };

      const response = await supertest(app).patch('/user/updateBadge').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid badge request body');
    });

    it('should return 400 for request missing badgeDescription', async () => {
      const mockReqBody = {
        username: mockUser.username,
        badgeTitle: 'Badge Title',
        badgeType: 'question' as 'question' | 'answer',
        action: 'add' as 'add' | 'remove',
      };

      const response = await supertest(app).patch('/user/updateBadge').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid badge request body');
    });

    it('should return 400 for request with invalid badgeType', async () => {
      const mockReqBody = {
        username: mockUser.username,
        badgeTitle: 'Badge Title',
        badgeDescription: 'Badge Description',
        badgeType: 'invalid-type', // Not 'question' or 'answer'
        action: 'add' as 'add' | 'remove',
      };

      const response = await supertest(app).patch('/user/updateBadge').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid badge request body');
    });

    it('should return 400 for request with invalid action', async () => {
      const mockReqBody = {
        username: mockUser.username,
        badgeTitle: 'Badge Title',
        badgeDescription: 'Badge Description',
        badgeType: 'question' as 'question' | 'answer',
        action: 'invalid-action', // Not 'add' or 'remove'
      };

      const response = await supertest(app).patch('/user/updateBadge').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid badge request body');
    });

    it('should successfully remove a badge given correct arguments', async () => {
      const existingBadge = {
        title: 'First Question',
        description: 'Asked your first question',
        type: 'question',
        dateAwarded: new Date(),
      };

      const mockReqBody = {
        username: mockUser.username,
        badgeTitle: existingBadge.title,
        badgeDescription: existingBadge.description, // This is what the controller will use for matching
        badgeType: 'question' as 'question' | 'answer',
        action: 'remove' as 'add' | 'remove',
      };

      // Mock the current user with the badge we want to remove
      getUserByUsernameSpy.mockResolvedValueOnce({
        ...mockSafeUser,
        badges: [existingBadge],
      });

      // Mock a successful update that returns user without the badge
      updatedUserSpy.mockResolvedValueOnce({
        ...mockSafeUser,
        badges: [], // Empty badges array after removal
      });

      const response = await supertest(app).patch('/user/updateBadge').send(mockReqBody);

      expect(response.status).toBe(200);
      expect(response.body).toEqual({
        ...mockUserJSONResponse,
        badges: [],
      });

      // Verify getUserByUsername was called
      expect(getUserByUsernameSpy).toHaveBeenCalledWith(mockUser.username);

      // Verify updateUser was called with empty badges array
      expect(updatedUserSpy).toHaveBeenCalledWith(mockUser.username, { badges: [] });
    });

    // 2. Fix for "should return 500 if getUserByUsername returns an error"
    it('should return 500 if getUserByUsername returns an error', async () => {
      const mockReqBody = {
        username: mockUser.username,
        badgeTitle: 'Badge Title',
        badgeDescription: 'Badge Description',
        badgeType: 'question' as 'question' | 'answer',
        action: 'add' as 'add' | 'remove',
      };

      // Simulate user not found with error property
      getUserByUsernameSpy.mockResolvedValueOnce({ error: 'User not found' });

      const response = await supertest(app).patch('/user/updateBadge').send(mockReqBody);

      // Update expectation to match controller behavior
      expect(response.status).toBe(404);
      expect(response.text).toContain('User not found');
    });

    // 3. Fix for "should return 500 if updateUser returns an error"
    it('should return 500 if updateUser returns an error', async () => {
      const mockReqBody = {
        username: mockUser.username,
        badgeTitle: 'Badge Title',
        badgeDescription: 'Badge Description',
        badgeType: 'question' as 'question' | 'answer',
        action: 'add' as 'add' | 'remove',
      };

      // Mock the current user with no badges
      getUserByUsernameSpy.mockResolvedValueOnce({
        ...mockSafeUser,
        badges: [],
      });

      // Use mockRejectedValueOnce to simulate an error being thrown
      updatedUserSpy.mockRejectedValueOnce(new Error('Error updating user'));

      const response = await supertest(app).patch('/user/updateBadge').send(mockReqBody);

      expect(response.status).toBe(500);
      expect(response.text).toContain('Error when updating user badges');
    });

    // 4. Fix for "should handle adding a badge when user already has other badges"
    it('should handle adding a badge when user already has other badges', async () => {
      const existingBadge = {
        title: 'First Question',
        description: 'Asked your first question',
        type: 'question',
        dateAwarded: new Date(),
      };

      const newBadge = {
        title: 'First Answer',
        description: 'Answered your first question', // Unique description for matching
        type: 'answer',
        dateAwarded: new Date(),
      };

      const mockReqBody = {
        username: mockUser.username,
        badgeTitle: newBadge.title,
        badgeDescription: newBadge.description,
        badgeType: newBadge.type as 'question' | 'answer',
        action: 'add' as 'add' | 'remove',
      };

      // Mock the current user with an existing badge
      getUserByUsernameSpy.mockResolvedValueOnce({
        ...mockSafeUser,
        badges: [existingBadge],
      });

      // Mock successful update with both badges
      const updatedUserWithBadges = {
        ...mockSafeUser,
        badges: [
          existingBadge,
          {
            title: newBadge.title,
            description: newBadge.description,
            type: newBadge.type,
            dateAwarded: newBadge.dateAwarded,
          },
        ],
      };

      updatedUserSpy.mockResolvedValueOnce(updatedUserWithBadges);

      const response = await supertest(app).patch('/user/updateBadge').send(mockReqBody);

      expect(response.status).toBe(200);

      // Verify updateUser was called with both badges
      expect(updatedUserSpy).toHaveBeenCalledWith(mockUser.username, {
        badges: [
          existingBadge,
          expect.objectContaining({
            title: newBadge.title,
            description: newBadge.description,
            type: newBadge.type,
          }),
        ],
      });
    });
  });

  describe('GET /getBadge/:username/:badgeDescription', () => {
    const getUserBadgeByTitleSpy = jest.spyOn(util, 'getUserBadgeByDescription');

    it('should return the badge when it exists for a user', async () => {
      const mockBadge: Badge = {
        title: 'First Answer',
        description: 'Answered your first question',
        type: 'answer',
        dateAwarded: new Date('2024-12-10'),
      };

      // Mock a successful badge retrieval
      getUserBadgeByTitleSpy.mockResolvedValueOnce(mockBadge);

      const response = await supertest(app).get(`/user/getBadge/${mockUser.username}/First Answer`);

      expect(response.status).toBe(200);
      expect(response.body).toEqual({
        title: mockBadge.title,
        description: mockBadge.description,
        type: mockBadge.type,
        dateAwarded: mockBadge.dateAwarded.toISOString(),
      });

      // Verify the service was called with the correct parameters
      expect(getUserBadgeByTitleSpy).toHaveBeenCalledWith(mockUser.username, 'First Answer');
    });

    it('should return 404 if username is not provided', async () => {
      const response = await supertest(app).get('/user/getBadge//First Answer');

      expect(response.status).toBe(404);
    });

    it('should return 404 if badge title is not provided', async () => {
      const response = await supertest(app).get(`/user/getBadge/${mockUser.username}/`);

      expect(response.status).toBe(404);
    });

    it('should return 500 if getUserBadgeByTitle returns an error for user not found', async () => {
      // Mock the error response
      getUserBadgeByTitleSpy.mockResolvedValueOnce({ error: 'User not found' });

      const response = await supertest(app).get(`/user/getBadge/${mockUser.username}/First Answer`);

      expect(response.status).toBe(500);
      expect(response.text).toContain('Error when getting badge by title');
    });

    it('should return 500 if getUserBadgeByTitle returns an error for badge not found', async () => {
      // Mock the error response
      getUserBadgeByTitleSpy.mockResolvedValueOnce({ error: 'Badge not found' });

      const response = await supertest(app).get(
        `/user/getBadge/${mockUser.username}/Nonexistent Badge`,
      );

      expect(response.status).toBe(500);
      expect(response.text).toContain('Error when getting badge by title');
    });

    it('should return 500 if getUserBadgeByTitle returns an error for user with no badges', async () => {
      // Mock the error response
      getUserBadgeByTitleSpy.mockResolvedValueOnce({ error: 'User has no badges' });

      const response = await supertest(app).get(`/user/getBadge/${mockUser.username}/Any Badge`);

      expect(response.status).toBe(500);
      expect(response.text).toContain('Error when getting badge by title');
    });

    it('should handle special characters in badge titles', async () => {
      const mockBadge: Badge = {
        title: 'Special & Badge!',
        description: 'A badge with special characters',
        type: 'question',
        dateAwarded: new Date('2024-12-10'),
      };

      // Mock a successful badge retrieval
      getUserBadgeByTitleSpy.mockResolvedValueOnce(mockBadge);

      // Use encodeURIComponent for the badge title with special characters
      const response = await supertest(app).get(
        `/user/getBadge/${mockUser.username}/${encodeURIComponent(mockBadge.title)}`,
      );

      expect(response.status).toBe(200);
      expect(response.body).toEqual({
        title: mockBadge.title,
        description: mockBadge.description,
        type: mockBadge.type,
        dateAwarded: mockBadge.dateAwarded.toISOString(),
      });
    });
  });

  describe('PATCH /updateInterests', () => {
    const interestId = new mongoose.Types.ObjectId();
    const mockSafeUserWithInterest = {
      ...mockSafeUser,
      interests: [interestId],
    };
    const mockSafeUserWithoutInterest = {
      ...mockSafeUser,
      interests: [],
    };
    const mockedInterest = {
      _id: interestId,
      title: 'mocked interest',
      description: 'mocked description',
      tags: ['tag1', 'tag2'],
    };
    it('should successfully add new interest given correct arguments', async () => {
      const mockReqBody = {
        username: mockUser.username,
        interestTitle: 'interest1',
        action: 'join',
      };

      getInterestByTitleSpy.mockResolvedValueOnce(mockedInterest);
      getUserByUsernameSpy.mockResolvedValueOnce(mockSafeUserWithoutInterest);
      updatedUserInterestSpy.mockResolvedValueOnce(mockSafeUserWithInterest);
      popDocSpy.mockResolvedValueOnce({
        ...mockSafeUserWithInterest,
        interests: [mockedInterest],
      });

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(200);
      expect(response.body.interests.length).toEqual(1);
    });
    it('should successfully delete new interest given correct arguments', async () => {
      const mockReqBody = {
        username: mockUser.username,
        interestTitle: 'interest1',
        action: 'leave',
      };

      getInterestByTitleSpy.mockResolvedValueOnce(mockedInterest);
      getUserByUsernameSpy.mockResolvedValueOnce(mockSafeUserWithInterest);
      updatedUserInterestSpy.mockResolvedValueOnce(mockSafeUserWithoutInterest);
      popDocSpy.mockResolvedValueOnce({
        ...mockSafeUserWithInterest,
        interests: [],
      });

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(200);
      expect(response.body.interests.length).toEqual(0);
    });

    it('should return 400 for request missing username', async () => {
      const mockReqBody = {
        interestTitle: 'interest1',
        action: 'join',
      };

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request with empty username', async () => {
      const mockReqBody = {
        username: '',
        interestTitle: 'interest1',
        action: 'join',
      };

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request missing interest title field', async () => {
      const mockReqBody = {
        username: mockUser.username,
        action: 'join',
      };

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request empty interest title field', async () => {
      const mockReqBody = {
        username: mockUser.username,
        interestTitle: '',
        action: 'join',
      };

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request empty action title field', async () => {
      const mockReqBody = {
        username: mockUser.username,
        interestTitle: '',
        action: '',
      };

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 400 for request invalid action title field', async () => {
      const mockReqBody = {
        username: mockUser.username,
        interestTitle: '',
        action: 'bad',
      };

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toEqual('Invalid user body');
    });

    it('should return 500 if getInterestByTitle returns an error', async () => {
      const mockReqBody = {
        username: mockUser.username,
        interestTitle: 'interestTitle',
        action: 'join',
      };

      // Simulate a DB error
      getInterestByTitleSpy.mockResolvedValueOnce({ error: 'Error updating user' });

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(500);
      expect(response.text).toContain(
        'Error when updating user interest: Error: Error updating user',
      );
    });
    it('should return 404 if getInterestByTitle returns not found', async () => {
      const mockReqBody = {
        username: mockUser.username,
        interestTitle: 'interestTitle',
        action: 'join',
      };

      // Stimulate a not found error
      getInterestByTitleSpy.mockResolvedValueOnce({ error: 'Interest not found' });

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(404);
      expect(response.text).toContain('Interest not found.');
    });

    it('should return 500 if getUserByUsername returns an error', async () => {
      const mockReqBody = {
        username: mockUser.username,
        interestTitle: 'interestTitle',
        action: 'join',
      };

      getInterestByTitleSpy.mockResolvedValueOnce(mockedInterest);
      // Simulate a DB error
      getUserByUsernameSpy.mockResolvedValueOnce({ error: 'Error getting user' });

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(500);
      expect(response.text).toContain(
        'Error when updating user interest: Error: Error getting user',
      );
    });

    it('should return 400  if user joins interest that they joined before', async () => {
      const mockReqBody = {
        username: mockUser.username,
        interestTitle: 'interestTitle',
        action: 'join',
      };

      getInterestByTitleSpy.mockResolvedValueOnce(mockedInterest);
      getUserByUsernameSpy.mockResolvedValueOnce(mockSafeUserWithInterest);

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toContain('User already has this interest.');
    });
    it('should return 400 if user leaves interest that they have not joined before', async () => {
      const mockReqBody = {
        username: mockUser.username,
        interestTitle: 'interestTitle',
        action: 'leave',
      };

      getInterestByTitleSpy.mockResolvedValueOnce(mockedInterest);
      getUserByUsernameSpy.mockResolvedValueOnce(mockSafeUserWithoutInterest);

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(400);
      expect(response.text).toContain('User does not have this interest.');
    });

    it('should return 500 if updateUserInterest returns an error', async () => {
      const mockReqBody = {
        username: mockUser.username,
        interestTitle: 'interestTitle',
        action: 'join',
      };

      getInterestByTitleSpy.mockResolvedValueOnce(mockedInterest);
      getUserByUsernameSpy.mockResolvedValueOnce(mockSafeUserWithoutInterest);
      // Simulate a DB error
      updatedUserInterestSpy.mockResolvedValueOnce({ error: 'Error updating user' });

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(500);
      expect(response.text).toContain(
        'Error when updating user interest: Error: Error updating user',
      );
    });

    it('should return 500 if populateDoc returns an error', async () => {
      const mockReqBody = {
        username: mockUser.username,
        interestTitle: 'interestTitle',
        action: 'join',
      };

      getInterestByTitleSpy.mockResolvedValueOnce(mockedInterest);
      getUserByUsernameSpy.mockResolvedValueOnce(mockSafeUserWithoutInterest);
      updatedUserInterestSpy.mockResolvedValueOnce(mockSafeUserWithInterest);
      // Simulate a DB error
      popDocSpy.mockResolvedValueOnce({ error: 'Error populating user' });

      const response = await supertest(app).patch('/user/updateInterests').send(mockReqBody);

      expect(response.status).toBe(500);
      expect(response.text).toContain(
        'Error when updating user interest: Error: Error populating user',
      );
    });
  });
  describe('GET /getUsersByInterest', () => {
    const interestId = new mongoose.Types.ObjectId();
    const mockedInterest = {
      _id: interestId,
      title: 'mocked interest',
      description: 'mocked description',
      tags: ['tag1', 'tag2'],
    };
    beforeEach(() => {
      jest.clearAllMocks();
    });
    afterEach(() => {
      jest.resetAllMocks();
    });

    it('should return the users from the database', async () => {
      getInterestByTitleSpy.mockResolvedValueOnce(mockedInterest);
      getUsersByInterestSpy.mockResolvedValueOnce([{ ...mockSafeUser, interests: [interestId] }]);

      popDocSpy.mockResolvedValueOnce({
        ...mockSafeUser,
        interests: [mockedInterest],
      });

      const response = await supertest(app).get(`/user/getUsersByInterest/${interestId}`);

      expect(response.status).toBe(200);
      expect(response.body.length).toEqual(1);
      expect(response.body[0].interests.length).toEqual(1);
      expect(getUsersByInterestSpy).toHaveBeenCalled();
    });

    it('should return 500 if database error while finding interest title', async () => {
      getInterestByTitleSpy.mockResolvedValueOnce({ error: 'Error retrieving interest' });
      getUsersByInterestSpy.mockResolvedValueOnce([{ ...mockSafeUser, interests: [interestId] }]);
      popDocSpy.mockResolvedValueOnce({
        ...mockSafeUser,
        interests: [mockedInterest],
      });

      const response = await supertest(app).get(`/user/getUsersByInterest/${interestId}`);

      expect(response.status).toBe(500);
    });

    it('should return 400 if not found while finding interest title', async () => {
      getInterestByTitleSpy.mockResolvedValueOnce({ error: 'Interest not found' });
      getUsersByInterestSpy.mockResolvedValueOnce([{ ...mockSafeUser, interests: [interestId] }]);
      popDocSpy.mockResolvedValueOnce({
        ...mockSafeUser,
        interests: [mockedInterest],
      });

      const response = await supertest(app).get(`/user/getUsersByInterest/${interestId}`);

      expect(response.status).toBe(404);
    });

    it('should return 500 if database error while populating user', async () => {
      getInterestByTitleSpy.mockResolvedValueOnce(mockedInterest);
      getUsersByInterestSpy.mockResolvedValueOnce([{ ...mockSafeUser, interests: [interestId] }]);
      popDocSpy.mockResolvedValueOnce({ error: 'Interest not found' });

      const response = await supertest(app).get(`/user/getUsersByInterest/${interestId}`);

      expect(response.status).toBe(500);
    });

    it('should return 500 if database error while finding users', async () => {
      getInterestByTitleSpy.mockResolvedValueOnce(mockedInterest);
      getUsersByInterestSpy.mockRejectedValueOnce(new Error('Error finding users'));
      popDocSpy.mockResolvedValueOnce({
        ...mockSafeUser,
        interests: [mockedInterest],
      });

      const response = await supertest(app).get(`/user/getUsersByInterest/${interestId}`);

      expect(response.status).toBe(500);
    });
  });
});
